<?php

function connexion()
{
 $host_name = 'localhost';
 $database = 'compte_samba';
 $user_name = 'root';
 $password = '';
 
 $connect = mysqli_connect($host_name, $user_name, $password, $database);
 
 if(mysqli_connect_errno())
 {
 return 'Echec de connexion au serveur:';
 }
 else
 {
   return  $connect;
 }
}
 ?>