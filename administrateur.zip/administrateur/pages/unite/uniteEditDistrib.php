<?php

 
 include('inc/connexion.php');
 $connect=connexion();
 mysqli_set_charset($connect, "utf8"); 
 $id=$_GET['id'];
 

 $queryDistrib="select  * from adherents where telClient='". $id."'";
 $resultDistrib = mysqli_query($connect, $queryDistrib);
 if(mysqli_num_rows($resultDistrib) > 0 ) 
{
   while($res = mysqli_fetch_array($resultDistrib))
   {
	$nom=$res['nomClient'];
	$tel=$res['telfixe'];
	$fax=$res['fax'];
	$BP=$res['BP'];
	$soldelimitdistrib=$res['soldelimitedistrib'];
	$quotepartdistrib=$res['quotepartdistrib'];
	$iban=$res['iban'];
	$cautiondistrib=$res['cautiondistrib'];
   }
}
mysqli_close($connect);
 ?>
<div class="container">
    <form action="" method="post">
        <fieldset>
            <legend>Généralités</legend>
            <div class="row py-0">
                <div class="col-md-3 mt-2">
                    <label>Désignation</label>
                </div>
                <div class="col-md-3">
               	 <?php echo '<input type="text" name="designation"    value="'.$nom.'">'; ?>
                </div>
                <div class="col-md-3 mt-2">
                    <label>Téléphone</label>
                </div>
                <div class="col-md-3">
             	 <?php echo '<input type="text" name="telfixe"    value="'.$tel.'">'; ?>
                </div>
            </div>
            <div class="row mb-0 py-0">
                <div class="col-md-3 mt-2">
                    <label>FAX</label>
                </div>
                <div class="col-md-3">
                   
					<?php echo '<input type="text" name="fax"    value="'.$fax.'">'; ?>
                </div>
                <div class="col-md-3 mt-2">
                    <label>BP</label>
                </div>
                <div class="col-md-3">
                
					<?php echo '<input type="text" name="BP"    value="'.$BP.'">'; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-md-5"></div>
                <div class="col-md-2">
                    <input type="submit" name="validerGeneralite" value="Valider">
                </div>
                <div class="col-md-5"></div>
            </div>
        </fieldset>
		 <?php
  
  global $id;

  if(isset($_POST['validerGeneralite'])){
	 $connect=connexion();
	 $UpdatetSQL = "UPDATE 	adherents SET nomClient='".$_POST['designation']."',telfixe='".$_POST['telfixe']."',fax='".$_POST['fax']."',BP='".$_POST['BP']."' WHERE telClient='".$id."'";
	
	 if(mysqli_query($connect, $UpdatetSQL)){ 
		    if (mysqli_affected_rows($connect) > 0){
				echo '<script type="text/javascript">alert("Mise a jour réussie")</script>' ;
				$location="admin.php?section=unite&page=uniteEditDistrib&id=".$id;
                echo '<META HTTP-EQUIV="Refresh" Content="0; URL='.$location.'">';
			}else{
				echo '<script type="text/javascript">alert("Echec de mise a jour")</script>' ;
			}
			
		 }
		 mysqli_close($connect);
  }
  ?>
    </form>
    <br>
    <fieldset>
        <legend>Paramètres Comptables</legend>
        <div class="container">
        <fieldset>
            <legend style="height:35px">Généralités</legend>
        <form action="" method="post">
            <div class="row py-0">
                <div class="col-md-2"></div>
                <div class="col-md-2 mt-2">
                    <label>Limitation de solde</label>
                </div>
                <div class="col-md-3">
                    <?php //$n = 500000000; echo number_format($n,0,'.',' '); ?>
                  
					<?php echo '<input type="text" name="solde"    value="'.number_format($soldelimitdistrib,0,'.',' ').'">'; ?>
                </div>
                <div class="col-md-2">
                    <input type="submit" name="validerSolde" value="Valider">
                </div>
            </div>
			 <?php
  
  global $id;

  if(isset($_POST['validerSolde'])){
	 $connect=connexion();
	$soldelimite= str_replace(" ","",$_POST['solde']);
	 
	 $UpdatetSQL = "UPDATE 	adherents SET soldelimitedistrib='".$soldelimite."' WHERE telClient='".$id."'";
	
	 if(mysqli_query($connect, $UpdatetSQL)){ 
		    if (mysqli_affected_rows($connect) > 0){
				echo '<script type="text/javascript">alert("Mise a jour réussie")</script>' ;
				$location="admin.php?section=unite&page=uniteEditDistrib&id=".$id;
                echo '<META HTTP-EQUIV="Refresh" Content="0; URL='.$location.'">';
			}else{
				echo '<script type="text/javascript">alert("Echec de mise a jour")</script>' ;
			}
			
		 }
		 mysqli_close($connect);
  }
  ?>
        </form>
        <!--  -->
        <form action="" method="post">
            <div class="row py-0">
                <div class="col-md-2"></div>
                <div class="col-md-2 mt-2">
                    <label>Numéro de compte IBAN</label>
                </div>
                <div class="col-md-3">

					<?php echo '<input type="text" name="iban"    value="'.$iban.'">'; ?>
                </div>
                <div class="col-md-2">
                    <input type="submit" name="validerNumcompte" value="Valider">
                </div>
            </div>
						 <?php
  
  global $id;
  if(isset($_POST['validerNumcompte'])){
	 $connect=connexion();
	 $UpdatetSQL = "UPDATE 	adherents SET iban='".$_POST['iban']."' WHERE telClient='".$id."'";
	
	 if(mysqli_query($connect, $UpdatetSQL)){ 
		    if (mysqli_affected_rows($connect) > 0){
				echo '<script type="text/javascript">alert("Mise a jour réussie")</script>' ;
				$location="admin.php?section=unite&page=uniteEditDistrib&id=".$id;
                echo '<META HTTP-EQUIV="Refresh" Content="0; URL='.$location.'">';
			}else{
				echo '<script type="text/javascript">alert("Echec de mise a jour")</script>' ;
			}
			
		 }
		 mysqli_close($connect);
  }
  ?>
        </form>
        <!--  -->
        <form action="" method="post">
            <div class="row py-0">
                <div class="col-md-2"></div>
                <div class="col-md-2 mt-2">
                    <label>Caution</label>
                </div>
                <div class="col-md-3">
                  
					<?php echo '<input type="text" name="caution"    value="'.number_format($cautiondistrib,0,'.',' ').'">'; ?>
                </div>
                <div class="col-md-2">
                    <input type="submit" name="validerCaution" value="Valider">
                </div>
            </div>
					 <?php
  
  global $id;

  if(isset($_POST['validerCaution'])){
	 $connect=connexion();
	
	 $caution= str_replace(" ","",$_POST['caution']);
	 $UpdatetSQL = "UPDATE 	adherents SET cautiondistrib='".$caution."' WHERE telClient='".$id."'";
	
	 if(mysqli_query($connect, $UpdatetSQL)){ 
		    if (mysqli_affected_rows($connect) > 0){
				echo '<script type="text/javascript">alert("Mise a jour réussie")</script>' ;
				$location="admin.php?section=unite&page=uniteEditDistrib&id=".$id;
                echo '<META HTTP-EQUIV="Refresh" Content="0; URL='.$location.'">';
			}else{
				echo '<script type="text/javascript">alert("Echec de mise a jour")</script>' ;
			}
			
		 }
		 mysqli_close($connect);
  }
  ?>
        </form>
        </fieldset>
        <fieldset>
            <legend style="height:35px">Cash to Cash</legend>
            <form action="" method="post">
                <div class="row py-0">
                    <div class="col-md-2"></div>
                    <div class="col-md-2 mt-2">
                        <label>Quotepart</label>
                    </div>
                    <div class="col-md-3">
                    	<?php echo '<input type="text" name="quotepart"    value="'.$quotepartdistrib.'">'; ?>
                    </div>
                    <div class="col-md-2">
                        <input type="submit" name="validerquote" value="Valider">
                    </div>
                </div>
								 <?php
  
  global $id;

  if(isset($_POST['validerquote'])){
	 $connect=connexion();
	
	 $UpdatetSQL = "UPDATE 	adherents SET quotepartdistrib='".$_POST['quotepart']."' WHERE telClient='".$id."'";
	
	 if(mysqli_query($connect, $UpdatetSQL)){ 
		    if (mysqli_affected_rows($connect) > 0){
				echo '<script type="text/javascript">alert("Mise a jour réussie")</script>' ;
				$location="admin.php?section=unite&page=uniteEditDistrib&id=".$id;
                echo '<META HTTP-EQUIV="Refresh" Content="0; URL='.$location.'">';
			}else{
				echo '<script type="text/javascript">alert("Echec de mise a jour")</script>' ;
			}
			
		 }
		 mysqli_close($connect);
  }
  ?>
            </form>
        </fieldset>
        </div>
    </fieldset>
</div><br><br>
