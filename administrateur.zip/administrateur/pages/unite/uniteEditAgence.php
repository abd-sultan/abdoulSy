<?php
include('inc/connexion.php');
 $connect=connexion();
 mysqli_set_charset($connect, "utf8");
 $id=$_GET['id'];
$queryDistrib="select  * from adherents where telClient='". $id."'";
 $resultDistrib = mysqli_query($connect, $queryDistrib);
 if(mysqli_num_rows($resultDistrib) > 0 )
{
   while($res = mysqli_fetch_array($resultDistrib))
   {
	$nom=$res['nomClient'];
	$tel=$res['telfixe'];
	$fax=$res['fax'];
	$BP=$res['BP'];

   }
}
mysqli_close($connect);
 ?>
<div class="container">
    <form name="generalite" action="" method="post" >
        <fieldset>
            <legend>Généralités</legend>
            <div class="row py-0">
                <div class="col-md-3 mt-2">
                    <label>Désignation</label>
                </div>
                <div class="col-md-3">

					<?php echo '<input type="text" name="designation"    value="'.$nom.'">'; ?>
                </div>
                <div class="col-md-3 mt-2">
                    <label>Téléphone</label>
                </div>
                <div class="col-md-3">

					<?php echo '<input type="text" name="telfixe"    value="'.$tel.'">'; ?>
                </div>
            </div>
            <div class="row mb-0 py-0">
                <div class="col-md-3 mt-2">
                    <label>FAX</label>
                </div>
                <div class="col-md-3">

					<?php echo '<input type="text" name="fax"    value="'.$fax.'">'; ?>
                </div>
                <div class="col-md-3 mt-2">
                    <label>BP</label>
                </div>
                <div class="col-md-3">
        			<?php echo '<input type="text" name="BP"    value="'.$BP.'">'; ?>
                </div>
            </div>
            <hr style="margin-bottom:0">
            <div class="row">
                <div class="col-md-5"></div>
                <div class="col-md-2 mt-0">

					<input type="submit" name="validerGeneralite" value="Valider">
                </div>
                <div class="col-md-4"></div>
            </div>
        </fieldset>
		 <?php

  global $id;

  if(isset($_POST['validerGeneralite'])){
	 $connect=connexion();
	 $UpdatetSQL = "UPDATE 	adherents SET nomClient='".$_POST['designation']."',telfixe='".$_POST['telfixe']."',fax='".$_POST['fax']."',BP='".$_POST['BP']."' WHERE telClient='".$id."'";

	 if(mysqli_query($connect, $UpdatetSQL)){
		    if (mysqli_affected_rows($connect) > 0){
				echo '<script type="text/javascript">alert("Mise a jour réussie")</script>' ;
				$location="admin.php?section=unite&page=uniteEditAgence&id=".$id;
                echo '<META HTTP-EQUIV="Refresh" Content="0; URL='.$location.'">';
			}else{
				echo '<script type="text/javascript">alert("Echec de mise a jour")</script>' ;
			}

		 }
		 mysqli_close($connect);
  }
  ?>
    </form>
    <!-- Horaires -->
    <form name="generalite" method="post">
        <fieldset style="margin-top:10px;padding-bottom:10px">
            <legend>Horaires</legend>
            <div class="btn-group btn-group-sm">
                <input type="button" name="valider" value="Valider" data-toggle="modal" data-target="#modifhoraire" style="margin-left:10px">
            </div>
            <div class="container">
                <table  class="gridtable" width='700' border='1'>

                <?php
				  global $id;
				 $connect=connexion();
				  $query="SELECT * from horaires where numEntite='".$id."'";

				 $result = mysqli_query($connect, $query);
					if(mysqli_num_rows($result) > 0 )
					{
						echo" <tr>";
							echo"<td align=center width='20'><b>"."Jour"."</b></td>";
							echo"<td align=center width='20'><b>"."Ouverture"."</b></td>";
							echo"<td align=center width='20'><b>"."Fermeture"."</b></td>";
							echo" </tr>";
                            // $tab = [];
					   while($res = mysqli_fetch_array($result))
					   {
							echo" <tr>";
							echo"<td align=center width='20'><input type='text' name='jour[]' value='".$res['jour']."' disabled /></td>";
							echo"<td align=center width='20'><input type='text' name='Ouvert[]' value='".$res['Ouvert']."' /></td>";
							echo"<td align=center width='20'><input type='text' name='Fermer[]' value='".$res['Fermer']."' /></td>";
							echo" </tr>";
                            // $tab = $tab + array($res['jour']);
					   }
                       // echo mysqli_num_rows($result);
					}
					 mysqli_close($connect);
					 ?>
                </table>

            </div>
        </fieldset>
        <!-- Nouvelle plage horaire -->
        <div class="modal" tabindex="-1" role="dialog"  id="modifhoraire" style="margin-top:10%;">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                    <h5 class="modal-title">Modification des horaires <?php echo $res['jour'];?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true" style="color:white">&times;</span>
                    </button>
              </div>
              <div class="modal-body">
                    <p>Voulez-vous confirmer la modification ?</p>
              </div>
              <div class="modal-footer">
                <input type="button" data-dismiss="modal" value="NON" style="width:100px" >
                <!-- Si NON annuler l'ajout -->
                <input type="submit" name="confirmer" value="OUI" style="margin-right:25%;width:100px">
                <!-- Si OUI valider le formulaire et ajout l'unité -->
              </div>
            </div>
          </div>
        </div>

<br><br>
<?php
    $connect = connexion();
    if (ISSET($_POST['confirmer'])) {
        $query = "SELECT * from horaires where numEntite='".$id."'";
        $result = mysqli_query($connect, $query);
        $i = 0;
        if(mysqli_num_rows($result) > 0 ) {
            while($res = mysqli_fetch_array($result)) {
                $queryUpdate = 'UPDATE horaires SET Ouvert="'. $_POST['Ouvert'][$i] .'", Fermer="'. $_POST['Fermer'][$i]  .'" where numEntite="'. $id .'" and jour = "'. $res['jour']  .'"';
                echo $queryUpdate.'<br>';
                $i = $i + 1;

            if(mysqli_query($connect, $queryUpdate)){
                if (mysqli_affected_rows($connect) > 0){
                    //
                }else{
                    //echo '<script type="text/javascript">alert("Echec de mise a jour")</script>' ;
                    $location="admin.php?section=unite&page=uniteEditAgence&id=".$id;
                    echo '<META HTTP-EQUIV="Refresh" Content="0; URL='.$location.'">';
                }

             }
             }
        }
        }
    mysqli_close($connect);
?>
</form>
<script language="javascript">
	function doFunction( data )
	{
		var confirmation = confirm( "Voulez vous modifier de " + data) ;


		if( confirmation )
			{



			document.location.href = "pages/utilisateur/deconnectSession.php?id="+data ;



			}


	}

	</script>
