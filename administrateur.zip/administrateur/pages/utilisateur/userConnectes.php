
<?php

include('inc/connexion.php');

 $connect=connexion();





?>
<div class="row">
    <div class="col-md-12">
        <form action="admin.php?section=user&page=userConnectes" method="post">
            <fieldset>
                <legend>Filtres</legend>
                <div class="row">
                    <div class="col-md-2">
                        <label for="fonction">Fonction : </label>
                    </div>
                    <div class="col-md-4">
                            <select name="cbofonction" id="fonction" class="styled-select">
							<option value="TOUS">TOUS</option>
                     		    <option value="Caissier_BO">CAISSIER_BO</option>
                                <option value="Caissier">CAISSIER</option>
								<option value="Admin_Distrib">ADMIN_DISTRIB</option>
								<option value="Superviseur">SUPERVISEUR</option>
                                <option value="Superviseur_BO">SUPERVISEUR_BO</option>
								<option value="Controleur">CONTROLEUR</option>
								<?php

								if ($_SESSION['typ']=="Caissier_BO"){
								echo '<option selected="selected" value="'.strtoupper($_SESSION['typ']).'"></option>';

								}
								?>
                            </select>
                    </div>
                <div class="col-md-2" style="margin-top:-15px">
                        <input type="button" name="afficher" value="Afficher">
                </div>
                </div>
            </fieldset>
        </form>
    </div>
</div>
<br><br><br>
<div class="row">
    <div class="col-md-12">
        <table  class="gridtable" width='700' border='1'>
            <thead>
                <tr>

                    <td ><b>Login</b></td>
                    <td ><b>Nom</b></td>
                    <td ><b>Prénom</b></td>
                    <td ><b>Fonction</b></td>
					<td ><b>Affectation</b></td>
                    <td ><b>Actions</b></td>
                </tr>
            </thead>
            <tbody>
              <!--  <tr>
                    <td>1234</td>
                    <td>log1234</td>
                    <td>BA</td>
                    <td>Alassane</td>
                    <td>Agence Foire</td>
                    <td>Administrateur</td>
                    <td class="text-center"><a href="admin.php?section=user&page=userEdit&id=5"><i class="fa fa-edit"></i></a></td>
                </tr>
                <tr>
                    <td>5678</td>
                    <td>log5678</td>
                    <td>DIALLO</td>
                    <td>Alioune Badara</td>
                    <td>Agence Parcelles</td>
                    <td>Supervisuer</td>
                    <td class="text-center"><a href="admin.php?section=user&page=userEdit&id=14"><i class="fa fa-edit"></i></a></td>
                </tr> -->
				<?php

				  if (ISSET($_POST['afficher'])) {

				    $connect=connexion();
                    mysqli_set_charset($connect, "utf8");
					$typ=$_POST['cbofonction'];

					//echo $typ;
					$active="oui";
					if ($typ=="TOUS"){
						  $Superviseur="Superviseur";
					  $Distributeur="Admin_Distrib";
					   $Superviseur_BO="Superviseur_BO";
					   $Caisse_BO="Caissier_BO";
						$Controleur="Controleur";
						 $Caisse="Caissier";
							$active="oui";
					 $query="select  * from adherents where sessionactive='".$active."' and (typeClient='".$Superviseur."' or typeClient='".$Distributeur."' or typeClient='".$Superviseur_BO."' or typeClient='".$Caisse_BO."' or typeClient='".$Controleur."' or typeClient='".$Caisse."') order by dateInscription desc,nomClient ";

					}else
					{
						  $query="select  * from adherents where sessionactive='".$active."' and typeClient='".$typ."' order by nomClient ";
						  // echo $query;
					}

                    $result = mysqli_query($connect, $query);
					if(mysqli_num_rows($result) > 0 )
					{
					   while($res = mysqli_fetch_array($result))
					   {
							echo" <tr>";
							echo"<td align=center width='20'>".$res['telClient']."</td>";
							echo"<td align=center width='20'>".$res['nom']."</td>";
							echo"<td align=center width='20'>".$res['prenom']."</td>";


							echo"<td align=center width='20'>".$res['typeClient']."</td>";
							echo"<td align=center width='20'>".$res['agence']."</td>";
							//$location="admin.php?section=user&page=userList";
                           // echo '<META HTTP-EQUIV="Refresh" Content="0; URL='.$location.'">';
						   $action='<td class="text-center"><a onClick="confirmer('.$res['telClient'].');" id="btn-retirer" data-toggle="modal" data-target="#confirmation"><i class="fa fa-2x fa-power-off" style="color:green"></i></a></td>';

							//$action='<td class="text-center" width="5"><a href="admin.php?section=user&page=userEdit&id='.$res['telClient'].'"><i class="fa fa-power-off"></i></a></td>';
							echo $action;
							echo" </tr>";

					   }
					}
					 mysqli_close($connect);

				    }

				   else
					 {
					mysqli_set_charset($connect, "utf8");
					 $Superviseur="Superviseur";
					  $Distributeur="Admin_Distrib";
					   $Superviseur_BO="Superviseur_BO";
					   $Caisse_BO="Caissier_BO";
						$Controleur="Controleur";
						 $Caisse="Caissier";
							$active="oui";
					 $query="select  * from adherents where sessionactive='".$active."' and (typeClient='".$Superviseur."' or typeClient='".$Distributeur."' or typeClient='".$Superviseur_BO."' or typeClient='".$Caisse_BO."' or typeClient='".$Controleur."' or typeClient='".$Caisse."') order by dateInscription desc,nomClient ";
					 $result = mysqli_query($connect, $query);


					if(mysqli_num_rows($result) > 0 )
					{
					   while($res = mysqli_fetch_array($result))
					   {
							echo" <tr>";
							echo"<td align=center width='20'>".$res['telClient']."</td>";
							echo"<td align=center width='20'>".$res['nom']."</td>";
							echo"<td align=center width='20'>".$res['prenom']."</td>";


							echo"<td align=center width='20'>".$res['typeClient']."</td>";
							echo"<td align=center width='20'>".$res['agence']."</td>";
							//$action='<td class="text-center" width="5"><a href="admin.php?section=user&page=userEdit&id='.$res['telClient'].'"><i class="fa fa-power-off"></i></a></td>';
							 $action='<td class="text-center"><a href="#" onClick="confirmer('.$res['telClient'].');" id="btn-retirer" data-toggle="modal" data-target="#confirmation"><i class="fa fa-2x fa-power-off" style="color:green"></i></a></td>';

							echo $action;
							echo" </tr>";

					   }
					}
					 mysqli_close($connect);
				   }

			    ?>
            </tbody>


            <tfoot>
                <tr>
                    <td colspan="7">
                        <nav aria-label="Page navigation example">
                            <ul class="pagination">
                                <li class="page-item">
                                    <a class="page-link" href="#" tabindex="-1"><i class="fa fa-angle-double-left"></i></a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="#">1</a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="#">2</a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="#">3</a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="#"><i class="fa fa-angle-double-right"></i></a>
                                </li>
                            </ul>
                        </nav>
                    </td>
                </tr>
            </tfoot>
        </table>
    </div>
</div>

<script language="javascript">
	function confirmer( identifiant )
	{
		var confirmation = confirm( "Voulez vous fermer la session de " + identifiant) ;

        //console.log(modal);

		if( confirmation )
			{


			document.location.href = "pages/utilisateur/deconnectSession.php?id="+identifiant ;



			}


	}

	</script>
