<?php
$id=$_GET['id'];
function connexion()
{
 $host_name = 'localhost';
 $database = 'compte_samba';
 $user_name = 'root';
 $password = '';
 
 $connect = mysqli_connect($host_name, $user_name, $password, $database);
 
 if(mysqli_connect_errno())
 {
 return 'Echec de connexion au serveur:';
 }
 else
 {
   return  $connect;
 }
}

killSession($id);
function killSession($id){
	 $connect=connexion();

				
				 mysqli_set_charset($connect, "utf8"); 
				 $sessionactive="non";
				 $UpdateDeConnexion = "UPDATE adherents SET sessionactive='".$sessionactive."' WHERE telClient='".$id."'";
				 if(mysqli_query($connect, $UpdateDeConnexion)){ 
				     $location="../../admin.php?section=user&page=userConnectes";
					 
                    echo '<META HTTP-EQUIV="Refresh" Content="0; URL='.$location.'">';
				  }
}

				 
?>