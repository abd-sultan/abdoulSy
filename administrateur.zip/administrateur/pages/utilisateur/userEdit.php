<?php


 include('inc/connexion.php');
 $connect=connexion();
 mysqli_set_charset($connect, "utf8");
 $id=$_GET['id'];
 $query="select  * from adherents where telClient='".$id."'";
 $result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0 )
{
   while($res = mysqli_fetch_array($result))
   {
	$nom=$res['nom'];
	$prenom=$res['prenom'];
	$adresse=$res['adresse'];
	$telfixe=$res['telfixe'];
	$email=$res['mailClient'];
	$cellulaire=$res['cellulaire'];
	$password=$res['passwordClient'];
	$code=$res['pinClient'];
    $paramWeb=$res['paramWeb'];
	$paramGSM=$res['paramGSM'];
	$fonction=$res['typeClient'];
	$affectation=$res['agence'];
	$statut=$res['Accepter'];

   }
}
 $type="Siege";
 $query="select  telClient,nomClient from adherents where typeClient='". $type."'";
  $result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0 )
 {
   while ($row = mysqli_fetch_assoc($result))
	{
	  $Siege=$row['nomClient'];
	}
  }

$type="Agence";
 $query="select  telClient,nomClient from adherents where typeClient='". $type."'  order by nomClient ";
 $resultLstAgence = mysqli_query($connect, $query);


 $typeD="Distributeur";
 $queryDistrib="select  telClient,nomClient from adherents where typeClient='". $typeD."'  order by nomClient ";
 $resultDistrib = mysqli_query($connect, $queryDistrib);

  mysqli_close($connect);

?>
<div class="container">
    <form action="" method="post" name="form_generatites" id="form_generatites">
        <fieldset>
            <legend class="text-center" style="font-size:1em">Généralités</legend>
            <div class="row">
                <div class="col-md-4 mb-0">
                    <!-- <div class="form-group mb-0"> -->
                        <div class="row">
                            <div class="col-md-3 mt-3">
                                 <label>Nom <span style="color: red;">*</span></label>
                            </div>
                            <div class="col-md-9">
                                <input type="text"  placeholder="nom" name="nom"   id="nom" value="<?php echo $nom;?>" required />
                            </div>
                        </div>
                    <!-- </div> -->
                    <!-- <div class="form-group"> -->
                        <div class="row">
                            <div class="col-md-3 mt-3">
                                 <label>Adresse</label>
                            </div>
                            <div class="col-md-9">
                                <input type="text"  placeholder="adresse"   name="adresse" id="adresse"value="<?php echo $adresse;?>" />
                            </div>
                        </div>
                    <!-- </div> -->
                </div>
                <div class="col-md-4 mb-0">
                    <!-- <div class="form-group mb-0"> -->
                        <div class="row">
                            <div class="col-md-3 mt-3">
                                <label>Prénom</label>
                            </div>
                            <div class="col-md-9">
                                <input type="text"  placeholder="prénom"    name="prenom" id="prenom" value="<?php echo $prenom;?>" required  />
                            </div>
                        </div>
                    <!-- </div> -->
                    <!-- <div class="form-group"> -->
                        <div class="row mb-0">
                            <div class="col-md-3 mt-2">
                                <label>Téléphone</label>
                            </div>
                            <div class="col-md-9 mt-2">
                                <input type="tel"  placeholder="téléphone"   name="telfixe" id="telfixe" value="<?php echo $telfixe;?>"  pattern="[0-9]{9}" title="maximum 9 chiffres" onkeypress='return event.charCode >= 48 &&   event.charCode <= 57 ||    event.charCode == 46'  />
                            </div>
                        <!-- </div> -->
                    </div>
				</div>
                <div class="col-md-4 mt-2">
                    <!-- <div class="form-group mb-0"> -->
                        <div class="row">
                            <div class="col-md-3 mt-3">
                                <label for="email">Email</label>
                            </div>
                            <div class="col-md-9">
                                <input type="email"  placeholder="email"   name="email" id="email" value="<?php echo $email;?>"  />
                            </div>
                        </div>
                    <!-- </div> -->
                    <!-- <div class="form-group"> -->
                        <div class="row">
                            <div class="col-md-3">
                                <label for="cellulaire">Cellulaire</label>
                            </div>
                            <div class="col-md-9">
                                <input type="tel" placeholder="cellulaire"  name="cellulaire" id="cellulaire"value="<?php echo $cellulaire;?>" pattern="[0-9]{9}" title="maximum 9 chiffres" onkeypress='return event.charCode >= 48 &&   event.charCode <= 57 ||    event.charCode == 46' />
                            </div>
                        </div>
                    <!-- </div> -->
                </div>
            </div>
            <div class="row">
                <div class="col-md-2 offset-md-4">
                    <input type="submit" name='validerGeneralite' value='VALIDER'>
                </div>
                <div class="col-md-2">
                    <input type="submit" name='annulerGeneralite' value='ANNULER' formnovalidate>
                </div>
            </div>
        </fieldset>
    </form>

<?php
 if(isset($_POST['validerGeneralite'])){
	 $connect=connexion();
	 $UpdatetSQL = "UPDATE 	adherents SET nom='".$_POST['nom']."',prenom='".$_POST['prenom']."',adresse='".$_POST['adresse']."',telfixe='".$_POST['telfixe']."',mailClient='".$_POST['email']."',cellulaire='".$_POST['cellulaire']."' WHERE telClient='".$id."'";
         if(mysqli_query($connect, $UpdatetSQL)){
		    if (mysqli_affected_rows($connect) > 0){
				echo '<script type="text/javascript">alert("Mise a jour réussie")</script>' ;
				$location="admin.php?section=user&page=userEdit&id=".$id;
                 echo '<META HTTP-EQUIV="Refresh" Content="0; URL='.$location.'">';
			}else{
				echo '<script type="text/javascript">alert("Echec de mise a jour")</script>' ;
			}

		 }
		 mysqli_close($connect);

 }
  if(isset($_POST['annulerGeneralite'])){

  }

?>

    <!-- --> <br>
    <div class="row mt-0 mb-0 pb-0">
        <div class="col-md-6">
            <form action="" method="post" name="form_paramweb">
                <fieldset>
                    <legend class="text-center" style="font-size:1em">Paramètres web</legend>
                    <div class="form-group mb-0">
                        <div class="row">
                            <div class="col-md-5">
                                <label for="password">Mot de passe</label>
                            </div>
                            <div class="col-md-7">
                                  <input type="password"  placeholder="Mot de passe" name="password"   id="password" value="<?php echo $password;?>" pattern="[0-9]{4}" title="maximum 4 chiffres" onkeypress='return event.charCode >= 48 &&   event.charCode <= 57 ||    event.charCode == 46' required />
                            </div>
                        </div>
                    </div>
                    <div class="form-group mb-0">
                        <div class="row">
                            <div class="col-md-5">
                                <label for="password2">Confirmez le mot de passe</label>
                            </div>
                            <div class="col-md-7">
                                 <input type="password"  placeholder="Répétez le mot de passe" name="password2"   id="password2" value="<?php echo $password;?>"  pattern="[0-9]{4}" title="maximum 4 chiffres" onkeypress='return event.charCode >= 48 &&   event.charCode <= 57 ||    event.charCode == 46' required />
                            </div>
                        </div>
                    </div>
                    <div class="form-group mb-0">
                        <div class="row">
                            <div class="col-md-5">
                                <label for="statut_web">Statut</label>
                            </div>
                            <div class="col-md-7 form-inline">
                                <div class="form-check">

										   <input type="radio"  name="rdbweb"   value="yes" <?php echo ($paramWeb=='oui' ? 'checked' : '');?> >
                                    <label for="rd-web-active" class="form-check-label">Activé</label>
                                </div>
                                <div class="form-check" style="margin-left:15px">
                                     <input type="radio"  name="rdbweb"   value="yes" <?php echo ($paramWeb=='non' ? 'checked' : '');?> >
                                    <label for="rd-web-desactive" class="form-check-label">Désactivé</label>
                                </div>
                            </div>
                        </div>
                    </div>

					 <input type="submit" name='validerParamWeb' value='VALIDER'>
					  <input type="submit" name='annulerParamWeb' value='ANNULER' formnovalidate>
                </fieldset>
            </form>
        </div>
        <div class="col-md-6 mb-0">
            <form action="" method="post" name="form_paramgsm">
                <fieldset>
                    <legend class="text-center" style="font-size:1em">Paramètres GSM</legend>
                    <div class="form-group mb-0">
                        <div class="row">
                            <div class="col-md-5">
                                <label for="code">Code PIN</label>
                            </div>
                            <div class="col-md-7">
        					   <input type="text"  placeholder="Code Pin" name="code"   id="code" value="<?php echo $code;?>" pattern="[0-9]{6}" title="maximum 6 chiffres" onkeypress='return event.charCode >= 48 &&   event.charCode <= 57 ||    event.charCode == 46' required />
                            </div>
                        </div>
                    </div>
                    <div class="form-group mb-0">
                        <div class="row">
                            <div class="col-md-5">
                                <label for="code2">Confirmez le code PIN</label>
                            </div>
                            <div class="col-md-7">
                                <input type="text"  placeholder="Répétez le code PIN" name="code2"   id="code2" value="<?php echo $code;?>" pattern="[0-9]{6}" title="maximum 6 chiffres" onkeypress='return event.charCode >= 48 &&   event.charCode <= 57 ||    event.charCode == 46'  required />
                            </div>
                        </div>
                        <div class="form-group mb-0">
                            <div class="row">
                                <div class="col-md-5">
                                    <label for="statut_web">Statut</label>
                                </div>
                                <div class="col-md-7 form-inline">
                                    <div class="form-check">


										<input type="radio"  name="rdbgsm"   value="yes" <?php echo ($paramGSM=='oui' ? 'checked' : '');?> >
                                        <label for="rd-gsm-active" class="form-check-label">Activé</label>


                                    </div>
                                    <div class="form-check" style="margin-left:15px">
                                       <input type="radio"  name="rdbgsm"   value="yes" <?php echo ($paramGSM=='non' ? 'checked' : '');?> >
                                        <label for="rd-gsm-desactive" class="form-check-label">Désactivé</label>
                                    </div>
                                </div>
                            </div>
                        </div>

						 <input type="submit" name='validerParamGSM' value='VALIDER'>
					  <input type="submit" name='annulerParamGSM' value='ANNULER' formnovalidate>
                </fieldset>
            </form>
        </div>
    </div>
    <br>
    <form action="" method="post" name="form_affectation">
        <div class="row mt-0 pt-0">
            <div class="col-md-12">
                <table class="table table-sm table-bordered">
                    <thead>
                    <tr style="font-size:1em">
                        <th scope="col" colspan="4" class="table-title" style="font-size:1em">Affectations</th>
                    </tr>
                    <tr>
                        <td scope="col">Fonction</td>
                        <td scope="col">Affectation</td>
                        <td scope="col">Statut</td>
                        <td scope="col">Selectionner</td>
                    </tr>
                    </thead>
                    <tbody>
	               <tr>
					<?php
					echo"<td align=center width='20'>".$fonction."</td>";
					echo"<td align=center width='20'>".$affectation."</td>";
					echo"<td align=center width='20'>".$statut."</td>";
					echo '<td class="text-center"> <input type="radio" name="rbaffectation">';
					?>
					 </tr>


                    </tbody>
                </table>
            </div>
        </div>
        <!-- -->
        <div class="row">
            <div class="col-md-4"></div>
            <div class="col-md-4">

              	 <input type="button" name='modifAffectation' data-toggle="modal" data-target="#affectations" value='MODIFIER'>
					  <input type="submit" name='activeDesactive' value='ACTIVER/DESACTIVER' >

            </div>
            <div class="col-md-4"></div>
        </div>

   <?php

  global $id;

  if(isset($_POST['activeDesactive'])){
	   $connect=connexion();
	   if ($statut=="oui")  {$flag="non";}
	    if ($statut=="non")  {$flag="oui";}

	 $UpdatetSQL = "UPDATE 	adherents SET Accepter='".$flag."' WHERE telClient='".$id."'";
	 if(mysqli_query($connect, $UpdatetSQL)){
		    if (mysqli_affected_rows($connect) > 0){
				echo '<script type="text/javascript">alert("Mise a jour réussie")</script>' ;
				$location="admin.php?section=user&page=userEdit&id=".$id;
                 echo '<META HTTP-EQUIV="Refresh" Content="0; URL='.$location.'">';
			}else{
				echo '<script type="text/javascript">alert("Echec de mise a jour")</script>' ;
			}

		 }
		 mysqli_close($connect);
  }

if(isset($_POST['submitmodif']) or isset($_POST['modifAffectation'])){
if (isset($_POST['profil'])){
    	$profil = $_POST['profil'];
}
	switch ($profil) {
    case "Controleur":
	$fonction=$Siege;
        $retour=update_compte($id,$profil,$fonction);
        break;
    case "Agence":
	$chAg=$_POST['cboagence'];
	if ($chAg=="") { echo '<script type="text/javascript">alert("Selectionner une agence")</script>' ; exit(); }
	 $chAg = explode("-", $_POST['cboagence']);
     $nomAgence=$chAg[1];
	$profil=$_POST['cbofonction'];

	  $retour=update_compte($id,$profil,$nomAgence);
        break;
    case "backOffice":
	 $chAg = explode("-", $_POST['cboagence']);
     $nomAgence=$chAg[1];
	$profil=$_POST['cbofonction']."_BO";
	//echo $id.",".$profil.",".$nomAgence;
	  $retour=update_compte($id,$profil,$nomAgence);
        break;
	case "Admin_Distrib":
	  $fonction=$_POST['cbodistrib'];
       $retour=update_compte($id,$profil,$fonction);
        break;
     }



}
 function update_compte($id,$profil,$fonction){
		   $connect=connexion();
	 $UpdatetSQL = "UPDATE 	adherents SET typeClient='".$profil."',agence='".$fonction."' WHERE telClient='".$id."'";
         if(mysqli_query($connect, $UpdatetSQL)){
		    if (mysqli_affected_rows($connect) > 0){
				echo '<script type="text/javascript">alert("Mise a jour réussie")</script>' ;
				$location="admin.php?section=user&page=userEdit&id=".$id;
                 echo '<META HTTP-EQUIV="Refresh" Content="0; URL='.$location.'">';
			}else{
				echo '<script type="text/javascript">alert("Echec de mise a jour")</script>' ;
			}

		 }
		 mysqli_close($connect);
	  }
?>
<div class="modal fade" tabindex="-1" role="dialog" id="affectations" area-labelledby="affectations" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                    <div class="modal-header"  style="background:black;color:white">
                        <h5 class="modal-title" class="text-center">Choisir une affectation</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <i class="fa fa-exit"></i>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                    <ul>

										<li>
										<!--<INPUT type= "radio" name="profil" value="Controleur" required> CONTROLEUR-->
										<input type="radio"  name="profil"   value="Controleur" <?php echo ($fonction=='Controleur' ? 'checked' : '');?> required> CONTROLEUR
										</li>
										<li><input type="radio"  name="profil"   value="Agence" <?php echo (($fonction=='Superviseur' or $fonction=='Caissier')  ? 'checked' : '');?> required> AGENCE
										<!--AGENCE <INPUT type= "radio" name="profil" value="Agence" required> AGENCE-->
                                        <ul>
                                            <li>
                                               <!-- <select name="agence" class="custom-select" multiple>
                                                    <option value="AgenceParcelles">Agence Parcelles</option>
                                                    <option value="AgenceFoire">Agence Foire</option>
													 </select>  -->
													 <?php
													  global $resultLstAgence;
													  echo '<select name="cboagence" class="styled-select" >';
													  echo '<option  value="'."".'">'."".'</option>';
												     	if(mysqli_num_rows($resultLstAgence) > 0 )
                                                         {
                                                   		   while ($row = mysqli_fetch_assoc($resultLstAgence))
															{
																if ($row['telClient']==$affectation)
																	{
																	 echo '<option  selected="selected" value="'.$row['telClient']."-".$row['nomClient'].'">'.$row['telClient']."-".$row['nomClient'].'</option>';
																    }
																else
																    {
																	 echo '<option  value="'.$row['telClient']."-".$row['nomClient'].'">'.$row['telClient']."-".$row['nomClient'].'</option>';
																    }

															}
															echo '</select>';

	                                                      }
													  ?>

                                            </li>
                                        </ul>
                                        </li>
										<li>
										<!--<INPUT type= "radio" name="profil" value="backOffice" required> BACK OFFICE-->
										<input type="radio"  name="profil"   value="backOffice" <?php echo (($fonction=='Superviseur_BO' or $fonction=='Caissier_BO') ? 'checked' : '');?> required> BACK OFFICE

										</li>
										<li>
										<!--<INPUT type= "radio" name="profil" value="Distributeur" required> DISTRIBUTEUR-->
										<input type="radio"  name="profil"   value="Admin_Distrib" <?php echo ($fonction=='Admin_Distrib'  ? 'checked' : '');?> required> DISTRIBUTEUR
										<ul>
										<li>
										 <!-- <select name="agence" class="custom-select" multiple>
                                                    <option value="AgenceParcelles">Agence Parcelles</option>
                                                    <option value="AgenceFoire">Agence Foire</option>
													 </select>  -->
													 <?php
													  global $resultDistrib;
													   global $affectation;
													  echo '<select name="cbodistrib" class="styled-select" >';
													  echo '<option  value="'."".'">'."".'</option>';
												     	if(mysqli_num_rows($resultDistrib) > 0 )
                                                         {
                                                   		   while ($row = mysqli_fetch_assoc($resultDistrib))
															{
																 if ($row['nomClient']==$affectation)
																 {
		                                                          echo '<option required selected value="'.$row['nomClient'].'">'.$row['nomClient'].'</option>';
																 }
																 else
																 {
																	 echo '<option required  value="'.$row['nomClient'].'">'.$row['nomClient'].'</option>';
																 }

															}

	                                                      }
														  echo '</select>';
													  ?>
										</li>
										</ul>
										</li>
                                    </ul>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="fonction">FONCTION</label>
                                    <select name="cbofonction" id="fonction" class="styled-select" >
									    <option value="" selected></option>
										<?php
										if ($fonction=="Superviseur" or $fonction=="Superviseur_BO")
                 						 {
											echo '<option selected="selected" value="Superviseur">SUPERVISEUR</option>';
										   }
										   else
										   {
											   echo '<option  value="Superviseur">SUPERVISEUR</option>';
										   }
										   if ($fonction=="Caissier" or$fonction=="Caissier_BO" )
                 						 {
											echo '<option selected="selected" value="Caissier">CAISSIER</option>';
										   }
										   else
										   {
											   echo '<option  value="Caissier">CAISSIER</option>';
										   }
										   ?>


                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit"  name="submitmodif">Valider</button>
                    </div>

                    </div>
                </div>
                </div>
    </form>
    <br><br>
</div>

<!-- Fenêtre de confirmation -->
<div class="modal" tabindex="-1" role="dialog" id="confirmation">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Modification de l'utilisateur</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p>Voulez-vous confirmer ?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">NON</button>
        <button type="button" class="btn btn-defaul">OUI</button>
      </div>
    </div>
  </div>
</div>
