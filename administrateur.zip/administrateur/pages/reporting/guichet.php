<?php
    include('inc/connexion.php')
?>
<div class="row">
    <div class="col-md-12">
        <form action="" method="post">
            <fieldset>
                <legend>Filtres</legend>
                <div class="row">
                    <div class="col-md-1">
                        <div class="">
                            <label for="fonction">Du : </label>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <input type="date" name="Du" value="<?php echo $_SESSION['Du']; ?>">
                    </div>
                    <div class="col-md-1">
                        <div class="">
                            <label for="fonction">Au : </label>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <input type="date" name="Au" value="<?php echo $_SESSION['Au']; ?>">
                    </div>
                    <div class="col-md-2 mt-2">
                        <?php
                        $connect = connexion();
                        $typeA="Agence";
                        $queryAgence="select  telClient,nomClient from adherents where typeClient='". $typeA."'  order by nomClient ";
                        $result = mysqli_query($connect, $queryAgence);
                         echo '<select name="cboagence" class="styled-select" >';
                         echo '<option  value="'."TOUS".'">'."TOUS".'</option>';
                           if(mysqli_num_rows($result) > 0 )
                            {
                              while ($row = mysqli_fetch_assoc($result))
                               {
                                 echo '<option  value="'.$row['telClient']."-".$row['nomClient'].'">'.$row['telClient']."-".$row['nomClient'].'</option>';
                               }
                               echo '</select>';
                             }
                            mysqli_close($connect);
                         ?>
                     </div>
                     <div class="col-md-2 mt-2">
                         <input type="submit" name="afficher" value="Afficher" style="margin-top:-10px">
                     </div>
                </div>
            </fieldset>
        </form>
    </div>
</div>
<?php
?>
<div  align="center" class="container">
            <!-- zone de connexion -->
<center>

<tr>
<td align=left>
<br>
<br>
 <?php
 if (ISSET($_POST['afficher'])) {
     $_SESSION['Du'] = $_POST['Du'];
     $_SESSION['Au'] = $_POST['Au'];
     $host_name = 'localhost';
     $database = 'compte_samba';
     $user_name = 'root';
     $password = '';
      $connect = mysqli_connect($host_name, $user_name, $password, $database);

if(mysqli_connect_errno())
 {
 echo 'Connexion au serveur MySQL a echoue:';
 }
 else
 {

    $connect;

   mysqli_set_charset($connect, "utf8");

   $typ="Siege";
    $query="select  *  from adherents where typeClient ='".$typ."'";


    $result = mysqli_query($connect, $query);
		if(mysqli_num_rows($result) > 0 ) {
       while($res = mysqli_fetch_array($result))
       {
       // echo "succes" ;
		$stel=$res['telClient'];

       }
	   mysqli_close($connect);
}
 }


       // $stel="20032003";

		$from=$_POST['Du'];
		$to=$_POST['Au'];

		$from=str_replace("/","-",$from);
		$to=str_replace("/","-",$to);

		$agence=$_POST['cboagence'];
		if ($agence=="TOUS"){
			$agenceChoix=$agence;
		}
		else{
			$sagence = explode("-", $agence);
			$agenceChoix=$sagence[0];
		}

       // echo $sagence[0];
		//echo $mois;
		$TransfEmis="0";
		$TransfRecu="0";
		$Retrait="0";
		$totalEncaissement="0";
		$totalDecaissement="0";

		affichage($from,$to,$stel,$agenceChoix);
}


 function affichage($from,$to,$tel,$flag){


 $host_name = 'localhost';
 $database = 'compte_samba';
 $user_name = 'root';
 $password = '';
  $connect = mysqli_connect($host_name, $user_name, $password, $database);
			 mysqli_set_charset($connect, "utf8");

echo '<br>';


	 echo "<td align=center>Agence : " .$flag." <br><br> Du : ".date("d-m-Y",strtotime($from))."  Au : ". date("d-m-Y",strtotime($to));
echo '<br>';
echo '<br>';

$from=date("Y-m-d",strtotime($from));
$to=date("Y-m-d",strtotime($to));
 $csv_export="";
			  $annule="Annule";
 $etat="Clôturée";
//and status <>'". $annule . "'
$sType="Transferts";
        $query="select  *  from commisions where Type='".$sType."'";
        $result = mysqli_query($connect, $query);
        while($res = mysqli_fetch_array($result))
         {
		   $pourcentage=$res['Recepteur'] / 100;
          $pourcentageEmmeteur=$res['Emetteur'] / 100;
         }

	$TransfRecu="0";
	$TransfEmis="0";
	$Retrait="0";
        $totalEncaissement=0;
        $totalDecaissement=0;
		//$flag=$tel;
	if ($flag=="TOUS"){

	}else
	{
		$tel=$flag;
	}

	if ($flag=="TOUS"){

		$query="select  sum(Montant) as total,sum(fraisTransaction *".$pourcentage.") as commission,dateTransaction,telRecepteur  from transactions where numsiegecloture ='". $tel."' and status <>'". $annule . "' and date(dateCloture) between '$from' and '$to' ";
		//echo $query;
	}else
	{
		$query="select  sum(Montant) as total,sum(fraisTransaction *".$pourcentage.") as commission,dateTransaction,telRecepteur  from transactions where numagencecloture ='". $tel."' and status <>'". $annule . "' and date(dateCloture) between '$from' and '$to' ";
	}

    $result = mysqli_query($connect, $query);
    if(mysqli_num_rows($result) > 0 ) {
       while($res = mysqli_fetch_array($result))
       {
        $TransfRecu=$res['commission'];
        $totalDecaissement=$res['total'];
       }

    }

	//-----------------

	  if ($flag=="TOUS"){
		   $query="select  sum(Montant+fraisTransaction) as montant,sum(fraisTransaction *".$pourcentageEmmeteur.") as commission,dateTransaction,telEmetteur  from transactions where numsiege='". $tel."' and status <>'". $annule . "' and date(dateTransaction) between '$from' and '$to'";

	  }else
	  {
		   $query="select  sum(Montant+fraisTransaction) as montant,sum(fraisTransaction *".$pourcentageEmmeteur.") as commission,dateTransaction,telEmetteur,numagence  from transactions where numagence='". $tel."' and status <>'". $annule . "' and date(dateTransaction) between '$from' and '$to'";

	  }

	$result = mysqli_query($connect, $query);
    if(mysqli_num_rows($result) > 0 ) {
       while($res = mysqli_fetch_array($result))
       {
        $TransfEmis=$res['commission'];
        $totalEncaissement=$res['montant'];
		//echo $TransfEmis;
       }

    }

	//-----------------Retrait--------------------
	// recupere le % des commisions
		$sType="Retraits";
        $query="select  *  from commisions where Type='".$sType."'";
        $result = mysqli_query($connect, $query);
        while($res = mysqli_fetch_array($result))
         {
		   $pourcentageEm=$res['Emetteur'] / 100;
         }
		 //echo $pourcentage;
$typOp="Retrait";
$status="Accepte";
 if ($flag=="TOUS"){
	 $query="select  sum(Montant-fraisRetrait) as total,sum(fraisRetrait *".$pourcentageEm.") as
commission,telEmetteur,Montant,dateTransaction from transferts where numsiege ='". $tel."' and typeOperation='".$typOp."' and date(dateTransaction) between '$from' and '$to' and status='".$status."'";

 }
 else
 {
	$query="select  sum(Montant-fraisRetrait) as total,sum(fraisRetrait *".$pourcentageEm.") as
commission,telEmetteur,Montant,dateTransaction,numagence from transferts where numagence ='". $tel."' and typeOperation='".$typOp."' and date(dateTransaction) between '$from' and '$to' and status='".$status."'";

 }
 $result = mysqli_query($connect, $query);
    if(mysqli_num_rows($result) > 0 ) {
       while($res = mysqli_fetch_array($result))
       {
        $Retrait=$res['commission'];
	   $totalDecaissement=$totalDecaissement+$res['total'];
       }

    }
//------Recharge-------------------

$typOp="Recharge";
if ($flag=="TOUS"){
$query="select  sum(Montant) as total,sum(fraisRetrait *".$pourcentage.") as commission,Montant,dateTransaction,telRecepteur from transferts where numsiege ='". $tel."' and status='".$status."' and typeOperation='".$typOp."'  and date(dateTransaction) between '$from' and '$to'";

}
else
{
$query="select  sum(Montant) as total,sum(fraisRetrait *".$pourcentage.") as commission,Montant,dateTransaction,telRecepteur,numagence from transferts where numagence ='". $tel."' and status='".$status."' and typeOperation='".$typOp."'  and date(dateTransaction) between '$from' and '$to'";

}
$result = mysqli_query($connect, $query);
    if(mysqli_num_rows($result) > 0 ) {
       while($res = mysqli_fetch_array($result))
       {

	$totalEncaissement=$totalEncaissement+$res['total'];
       }

    }
  $TransfEmis = number_format($TransfEmis, 0, ',', ' ');
  $TransfRecu = number_format($TransfRecu, 0, ',', ' ');
  $Retrait = number_format($Retrait, 0, ',', ' ');
  $totalEncaissement = number_format($totalEncaissement, 0, ',', ' ');
  $totalDecaissement = number_format($totalDecaissement, 0, ',', ' ');




   	echo "<table  class='gridtable'  width='600' border='1'>";
  echo" <tr>";
       echo"<td align=right width='150'><b>Transf. Emis.</td></b>";
       echo"<td align=right width='150'><b>Transf. Recu.</td></b>";
       echo"<td align=right width='150'><b>Retrait</b></td>";
	    echo"<td align=right width='150'><b>Encaissement</b></td>";
		 echo"<td align=right width='150'><b>Decaissement</b></td>";


   echo'</tr>';
 echo"<tr with='800'>";
 echo"<td align=right width='150'>".$TransfEmis."</td>";
  echo"<td align=right width='150'>".$TransfRecu."</td>";
   echo"<td align=right width='150'>".$Retrait."</td>";
    echo"<td align=right width='150'>".$totalEncaissement."</td>";
	 echo"<td align=right width='150'>".$totalDecaissement."</td>";




    echo'</tr>';
	$csv_export.= "Transf Emis".","."Transf Recu".","."Retrait".","."Encaissement".","."Decaissement"."\n";


	$csv_export.= $TransfEmis.",".$TransfRecu.",".$Retrait.",".$totalEncaissement.",".$totalDecaissement;

	  mysqli_close($connect);
     $_SESSION['data']= $csv_export;
     $_SESSION['typ']= "CommissionsCNCAS";

		 }
?>



</td>
</tr>

</center>
  </div>
