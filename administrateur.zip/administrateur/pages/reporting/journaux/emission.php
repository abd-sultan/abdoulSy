<?php
    if (ISSET($_POST['afficher'])) {
    $_SESSION['Du'] = $_POST['Du'];
    $_SESSION['Au'] = $_POST['Au'];
    $from=$_POST['Du'];
    $to=$_POST['Au'];
    $from=str_replace("/","-",$from);
    $to=str_replace("/","-",$to);
    $connect = connexion();
    $tel=$_SESSION['numero'];
    $annule="Annule";
    $status="envoie";
    $sType="Transferts";
    $query="select  *  from commisions where Type='".$sType."'";
    $result = mysqli_query($connect, $query);
    while($res = mysqli_fetch_array($result))
    {
        $pourcentage = $res['Emetteur'] / 100;
    }
    $agence=$_POST['cboagence'];
    if ($agence=="TOUS"){
        $agenceChoix=$agence;
        $query="select  refEmetteur,sum(Montant) as montant,sum(fraisTransaction *".$pourcentage.") as commission,date(dateTransaction) as dat,time(dateTransaction) as heure,fraisTransaction,telEmetteur,SousDistrib  from transactions where status <>'". $annule . "' and date(dateCloture) between '".$from."' and '".$to."' group by dateTransaction desc,telEmetteur";
    }
    else {
        $sagence = explode("-", $agence);
        $agenceChoix=$sagence[0];
        $query="select  refEmetteur,sum(Montant) as montant,sum(fraisTransaction *".$pourcentage.") as commission,date(dateTransaction) as dat,time(dateTransaction) as heure,fraisTransaction,telEmetteur,SousDistrib  from transactions where numagence='". $agenceChoix."' and status <>'". $annule . "' and date(dateCloture) between '".$from."' and '".$to."' group by dateTransaction desc,telEmetteur";

    }
    $result = mysqli_query($connect, $query);
    if(mysqli_num_rows($result) > 0 ) {
        while($res = mysqli_fetch_array($result)) {
            $temp_array["refEmetteur"]= $res['refEmetteur'];
            $temp_array["Beneficiaire"]= $res['telEmetteur'];
            $temp_array["Montant"]= $res['montant'];
            $temp_array["fraisTransaction"]= $res['fraisTransaction'];
            $temp_array["Commission"]=$res['commission'];
            $temp_array["Date"]=$res['dat'];
            $temp_array["Heure"]=$res['heure'];
            $temp_array["numcaisse"]=$res['SousDistrib'];
            $refEmetteur=$temp_array['refEmetteur'];
            echo"<td align=center width='20'>"."<a href='ficheemis.php?refEmetteur=$refEmetteur'>".$temp_array['refEmetteur']."</a>"."</td>";
            echo"<td align=center width='30'>".$temp_array['Beneficiaire']."</td>";
            echo"<td align=right width='50'>".number_format($temp_array['Montant'], 0, ',', ' ')."</td>";
            echo"<td align=right width='50'>".number_format($temp_array['fraisTransaction'], 0, ',', ' ')."</td>";
            echo"<td align=right width='50'>".number_format($temp_array['Commission'], 0, ',', ' ')."</td>";
            echo"<td align=center width='50'>".date("d-m-Y",strtotime($temp_array['Date']))."</td>";
            echo"<td align=center width='50'>".$temp_array['Heure']."</td>";
            echo"<td align=center width='50'>".$temp_array['numcaisse']."</td>";
            echo'</tr>';
        }
    } // end if mysqli_num_rows($resultCl) > 0
    else
    {
        echo 'Aucune donnée pour la requête';
    }
    mysqli_close($connect);
}
?>
