<?php
    if (ISSET($_POST['afficher'])) {
    $_SESSION['Du'] = $_POST['Du'];
    $_SESSION['Au'] = $_POST['Au'];
    $from=$_POST['Du'];
    $to=$_POST['Au'];
    $from=str_replace("/","-",$from);
    $to=str_replace("/","-",$to);
    $connect = connexion();
    $tel=$_SESSION['numero'];
    $annule="Annule";
    $status="Accepte";
    $typEmetteur="Entreprise";
    $typRecepteur="Particulier";
    $sType="Retraits";
    $query="select  *  from commisions where Type='".$sType."'";
    $result = mysqli_query($connect, $query);
    while($res = mysqli_fetch_array($result))
    {
        $pourcentage = $res['Emetteur'] / 100;
    }
    $agence=$_POST['cboagence'];
    $typOp="Recharge";
    if ($agence=="TOUS"){
        $agenceChoix=$agence;
        $query="select  reference,Montant as total,fraisRetrait *".$pourcentage." as commission,Montant,fraisRetrait,dateTransaction,SousDistrib,telRecepteur,date(dateTransaction) as dat,time(dateTransaction) as heure from transferts where status ='". $status . "' and date(dateTransaction) between '".$from."' and '".$to."'  and typeOperation='".$typOp."' group by dateTransaction desc,telEmetteur";
    }
    else {
        $sagence = explode("-", $agence);
        $agenceChoix=$sagence[0];
        $query="select  reference,Montant as total,fraisRetrait *".$pourcentage." as commission,Montant,fraisRetrait,dateTransaction,SousDistrib,telRecepteur,date(dateTransaction) as dat,time(dateTransaction) as heure from transferts where numagence='". $agenceChoix."' and status ='". $status . "' and date(dateTransaction) between '".$from."' and '".$to."'  and typeOperation='".$typOp."' group by dateTransaction desc,telEmetteur";

    }
    $result = mysqli_query($connect, $query);
    if(mysqli_num_rows($result) > 0 ) {
        while($res = mysqli_fetch_array($result)) {
            $temp_array["reference"]= $res['reference'];
    	    $temp_array["Beneficiaire"]= $res['telRecepteur'];
    	    $temp_array["Montant"]= $res['total'];
    	    $temp_array["frais"]= $res['fraisRetrait'];
    	    $temp_array["Commission"]=$res['commission'];
    	    $temp_array["Date"]=$res['dat'];
            $temp_array["Heure"]=$res['heure'];
    	    $temp_array["SousDistrib"]=$res['SousDistrib'];
	        $reference=$temp_array['reference'];
            echo"<td align=center width='20'>"."<a href='ficherecharge.php?reference=$reference'>".$temp_array['reference']."</a>"."</td>";
            echo"<td align=center width='20'>".$temp_array['Beneficiaire']."</td>";
            echo"<td align=right width='50'>".number_format($temp_array['Montant'], 0, ',', ' ')."</td>";
            echo"<td align=right width='50'>".number_format($temp_array['frais'], 0, ',', ' ')."</td>";
            echo"<td align=right width='20'>".number_format($temp_array['Commission'], 0, ',', ' ')."</td>";
            echo"<td align=center width='50'>".date("d-m-Y",strtotime($temp_array['Date']))."</td>";
            echo"<td align=center width='50'>".$temp_array['Heure']."</td>";
            echo"<td align=center width='50'>".$temp_array['SousDistrib']."</td>";
            echo'</tr>';
        }
    } // end if mysqli_num_rows($resultCl) > 0
    else
    {
        echo 'Aucune donnée pour la requête';
    }
    mysqli_close($connect);
}
?>
