<?php
    include('inc/connexion.php')
?>
<div class="row">
    <div class="col-md-12">
        <form action="" method="post">
            <fieldset>
                <legend>Filtres</legend>
                <div class="row">
                    <div class="col-md-1">
                        <div class="">
                            <label for="fonction">Du : </label>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <input type="date" name="Du" value="<?php echo $_SESSION['Du']; ?>">
                    </div>
                    <div class="col-md-1">
                        <div class="">
                            <label for="fonction">Au : </label>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <input type="date" name="Au" value="<?php echo $_SESSION['Au']; ?>">
                    </div>
                    <div class="col-md-2 mt-2">
                        <?php
                        $connect = connexion();
                        $typeA="Agence";
                        $queryAgence="select  telClient,nomClient from adherents where typeClient='". $typeA."'  order by nomClient ";
                        $result = mysqli_query($connect, $queryAgence);
                         echo '<select name="cboagence" class="styled-select" >';
                         echo '<option  value="'."TOUS".'">'."TOUS".'</option>';
                           if(mysqli_num_rows($result) > 0 )
                            {
                              while ($row = mysqli_fetch_assoc($result))
                               {
                                 echo '<option  value="'.$row['telClient']."-".$row['nomClient'].'">'.$row['telClient']."-".$row['nomClient'].'</option>';
                               }
                               echo '</select>';
                             }
                            mysqli_close($connect);
                         ?>
                     </div>
                     <div class="col-md-2 mt-2">
                         <input type="submit" name="afficher" value="Afficher" style="margin-top:-10px">
                     </div>
                </div>
            </fieldset>
        </form>
    </div>
</div>
