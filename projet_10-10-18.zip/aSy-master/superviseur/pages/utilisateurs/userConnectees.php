<div class="row">
    <div class="col-md-12">
        <form action="" method="post">
            <fieldset>
                <legend>Filtres</legend>
                <div class="row">
                    <div class="col-md-1 mt-2">
                        <div class="">
                            <label for="fonction">Fonction : </label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <select name="fonction" id="fonction" class="styled-select">
                            <option value="administrateur">Administrateur</option>
                            <option value="superviseur">Superviseur</option>
                            <option value="caissier">Caissier</option>
                        </select>
                    </div>
                    <div class="col-md-5 mt-0">
                        <input type="button" name="rechercher" value="Rechercher" style="margin-top:-10px">
                    </div>
                </div>
            </fieldset>
        </form>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <table class="gridtable">
            <thead>
                <tr>
                    <th scope="col">Login</th>
                    <th scope="col">Nom</th>
                    <th scope="col">Prénom</th>
                    <th scope="col">Affectation</th>
                    <th scope="col">Fonction</th>
                    <th scope="col">Démarrée à</th>
                    <th scope="col">Média</th>
                    <th scope="col">Mode</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>log1234</td>
                    <td>BA</td>
                    <td>Alassane</td>
                    <td>Agence Foire</td>
                    <td>Administrateur</td>
                    <td>06/10/2018 <br> 12:21</td>
                    <td>192.168.14.56</td>
                    <td>WEB</td>
                    <td class="text-center"><a href="#" id="btn-retirer" data-toggle="modal" data-target="#confirmation"><i class="fa fa-2x fa-power-off" style="color:green"></i></a></td>
                </tr>
                <tr>
                    <td>log5678</td>
                    <td>DIALLO</td>
                    <td>Alioune Badara</td>
                    <td>Agence Parcelles</td>
                    <td>Supervisuer</td>
                    <td>06/10/2018 <br> 12:21</td>
                    <td>192.168.14.56</td>
                    <td>WEB</td>
                    <td class="text-center"><a href="#" id="btn-retirer" data-toggle="modal" data-target="#confirmation"><i class="fa fa-2x fa-power-off" style="color:green"></i></a></td>
                </tr>
            </tbody>
            <!-- <tfoot>
                <tr>
                    <td colspan="9">
                        <nav aria-label="Page navigation example">
                            <ul class="pagination">
                                <li class="page-item">
                                    <a class="page-link" href="#" tabindex="-1"><i class="fa fa-angle-double-left"></i></a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="#">1</a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="#">2</a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="#">3</a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="#"><i class="fa fa-angle-double-right"></i></a>
                                </li>
                            </ul>
                        </nav>
                    </td>
                </tr>
            </tfoot> -->
        </table>
    </div>
</div>

<div class="modal" tabindex="-1" role="dialog" id="confirmation">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Déconnecter l'utilisateur</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p>Voulez-vous confirmer ?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">NON</button>
        <button type="button" class="btn btn-defaul">OUI</button>
      </div>
    </div>
  </div>
</div>
