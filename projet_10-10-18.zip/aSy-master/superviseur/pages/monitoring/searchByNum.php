<div class="container">
    <form action="" method="post">
        <fieldset>
            <legend>Filtres</legend>
            <div class="row">
                <div class="col-md-1 mt-2">
                    <div class="">
                        <label for="fonction">Numèro </label>
                    </div>
                </div>
                <div class="col-md-4">
                    <input type="text" name="numero" value="">
                </div>
                <div class="col-md-5 mt-0">
                    <input type="button" name="rechercher" value="Rechercher" style="margin-top:0px">
                </div>
            </div>
        </fieldset>
    </form>
    <br><br>
    <table class="gridtable" width="700" border="1">
        <thead>
            <tr>
                <td><b>Type</b></td>
                <td><b>Numèro</b></td>
                <td><b>Date</b></td>
                <td><b>Caissier</b></td>
                <td><b>Caisse</b></td>
                <td><b>Actions</b></td>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Agence Foire</td>
                <td>Administrateur</td>
                <td>06/10/2018 <br> 12:21</td>
                <td>192.168.14.56</td>
                <td>WEB</td>
                <td class="text-center td-icons" style="font-size:1.5em">
                    <a href="#">
                        <i class="fa fa-search" style="color:blue"></i>
                    </a>
                    <a href="#" data-toggle="modal" data-target="#confirmLogout">
                        <i class='fa fa-times-circle' style="color:red"></i>
                    </a>
                    <a href="#" data-toggle="modal" data-target="#confirmBlock">
                        <i class='fa fa-lock' style="color:yellow"></i>
                    </a>
                    <a href="#">
                        <i class='fa fa-edit' style="color:green"></i>
                    </a>
                </td>
            </tr>
            <tr>
                <td>Agence Foire</td>
                <td>Administrateur</td>
                <td>06/10/2018 <br> 12:21</td>
                <td>192.168.14.56</td>
                <td>WEB</td>
                <td class="text-center td-icons" style="font-size:1.5em">
                    <a href="#"class="lienmodal" data-toggle="modal" data-target="#modalconfirm">
                        <i class="fa fa-search" style="color:blue"></i>
                    </a>
                    <a href="#" data-toggle="modal" data-target="#confirmLogout">
                        <i class='fa fa-times-circle' style="color:red"></i>
                    </a>
                    <a href="#" data-toggle="modal" data-target="#confirmBlock">
                        <i class='fa fa-lock' style="color:yellow"></i>
                    </a>
                    <a href="#">
                        <i class='fa fa-edit' style="color:green"></i>
                    </a>
                </td>
            </tr>
        </tbody>
    </table>
</div>

<div class="modal" tabindex="-1" role="dialog" id="confirmLogout">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Déconnection de l'utilisateur</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p>Voulez-vous vraiment déconnecter cet utilisateur ?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">NON</button>
        <button type="button" class="btn btn-defaul">OUI</button>
      </div>
    </div>
  </div>
</div>

<div class="modal" tabindex="-1" role="dialog" id="confirmBlock">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Blocage de l'utilisateur</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p>Voulez-vous vraiment bloquer cet utilisateur ?</p>
      </div>
      <div class="modal-footer">
        <input type="button" name="non_block" value="NON" data-dismiss="modal">
        <input type="submit" name="oui_block" value="OUI">
      </div>
    </div>
  </div>
</div>

<?php include('inc/confirm.php') ?>
