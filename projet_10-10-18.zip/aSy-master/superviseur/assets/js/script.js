$(function() {
    function confirmer(titre, texte) {
        $('#modalconfirm .modal-title').innerHTML = titre;
        $('#modalconfirm .modal-body p').innerHTML = texte;
        $('#modalconfirm').modal('show');
    }
    $('.lienmodal').click(function() {
        console.log(confirmer('titre','texte'));
    });
});
