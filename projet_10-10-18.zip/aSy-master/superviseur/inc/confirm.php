<div class="globalmodal">
    <div class="modal" tabindex="-1" role="dialog" id="modalconfirm">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title"></h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <p></p>
          </div>
          <div class="modal-footer">
            <input type="button" name="non_block" value="NON" data-dismiss="modal">
            <input type="submit" name="oui_block" value="OUI">
          </div>
        </div>
      </div>
    </div>
</div>
