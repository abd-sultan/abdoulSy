<?php
       session_start();
      // On detruit les sessions :
	unset($_SESSION['numero']);
 session_destroy();

// On redirige le visiteur vers la page d�sir�e :
	header('Location: ./Connexion.php');
	exit();

    //  echo "Vous avez d�connecter de mon site " ;
//header("location:http://www2.senevens.fr/TestAcceesWeb/Connexion.php");


?>
