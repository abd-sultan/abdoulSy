
<?php

include('inc/connexion.php');
 $connect=connexion();

 mysqli_set_charset($connect, "utf8");
  $type="Siege";
 $query="select  telClient,nomClient from adherents where typeClient='". $type."'";
  $result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0 )
 {
   while ($row = mysqli_fetch_assoc($result))
	{
	  $Siege=$row['nomClient'];
	}
  }
 $type="Agence";
 $query="select  telClient,nomClient from adherents where typeClient='". $type."'  order by nomClient ";
 $result = mysqli_query($connect, $query);

 $typeD="Admin_Distrib";
 $queryDistrib="select  telClient,nomClient from adherents where typeClient='". $typeD."'  order by nomClient ";
 $resultDistrib = mysqli_query($connect, $queryDistrib);

  mysqli_close($connect);





?>
<div class="container">
    <!-- Ajout -->
    <form action="" method="post">

        <fieldset style="width:700px">
            <legend>Nouvelle Unité Organisationnelle</legend>
            <div class="row">
                <div class="col-md-2 mr-0">
                    <label style="margin-top:15px;margin-left:25px">Nom</label>
                </div>
                <div class="col-md-5">
                    <input type="text" name="nom" value="" placeholder="Nom">
                </div>
                <div class="col-md-3">


					 <input type="submit" name='submit' value='Valider'>
                </div>
            </div>
    <!-- Sélection  -->
    <hr>
    <div class="row" style="padding:20px;">
        <ul>
            <li><INPUT type= "radio" name="profil" value="Agence"> AGENCE</li>
            <li><INPUT type= "radio" name="profil" value="Caisse"> CAISSE
                <ul>
                                            <li>
                                               <!-- <select name="agence" class="custom-select" multiple>
                                                    <option value="AgenceParcelles">Agence Parcelles</option>
                                                    <option value="AgenceFoire">Agence Foire</option>
													 </select>  -->
													 <?php
													  global $result;
													  echo '<select name="cboagence" class="styled-select" >';
													  echo '<option  value="'."".'">'."".'</option>';
												     	if(mysqli_num_rows($result) > 0 )
                                                         {
                                                   		   while ($row = mysqli_fetch_assoc($result))
															{
															  echo '<option  value="'.$row['nomClient'].'">'.$row['nomClient'].'</option>';
															}
															echo '</select>';
	                                                      }
													  ?>

                                            </li>
                                        </ul>
            </li>
            <li>
                <INPUT type= "radio" name="profil" value="backOffice"> BACK OFFICE
            </li>
            <li>
                <INPUT type= "radio" name="profil" value="Distributeur"> DISTRIBUTEUR
				 <ul>
                                            <li>
                                               <!-- <select name="agence" class="custom-select" multiple>
                                                    <option value="AgenceParcelles">Agence Parcelles</option>
                                                    <option value="AgenceFoire">Agence Foire</option>
													 </select>  -->
													 <?php
													  global $resultDistrib;
													  echo '<select name="cboAdminDistrib" class="styled-select" >';
													  echo '<option  value="'."".'">'."".'</option>';
												     	if(mysqli_num_rows($resultDistrib) > 0 )
                                                         {
                                                   		   while ($row = mysqli_fetch_assoc($resultDistrib))
															{
															   echo '<option  value="'.$row['telClient']."-".$row['nomClient'].'">'.$row['telClient']."-".$row['nomClient'].'</option>';

															}
															echo '</select>';
	                                                      }
													  ?>

                                            </li>
                                        </ul>
            </li>
        </ul>
    </div>
    </fieldset>
			<?php

 if (ISSET($_POST['submit'])) {

    $AdminDistrib=$_POST['cboAdminDistrib'];
    $agence = $_POST['cboagence'];
	$nom=$_POST['nom'];

if (isset($_POST['profil'])){
    	$profil = $_POST['profil'];
}
	switch ($profil) {
    case "Agence":
	    $fonction=$Siege;
        $retour=ajout_compte($profil,$fonction,$nom);

        break;
	case "Caisse":

	   $nomAgence =  $_POST['cboagence'];

      $retour= ajout_compte($profil,$nomAgence,$nom);
        break;
	case "Distributeur":

	   $chDistribAdmin= explode("-", $_POST['cboAdminDistrib']);
       $DistribAdmin=$chDistribAdmin[1];

      $retour= ajout_compte($profil,$DistribAdmin,$nom);
        break;

	case "backOffice":
	    $fonction=$Siege;
        $retour=ajout_compte($profil,$fonction,$nom);
        break;


     }

 }


function ajout_compte($profil,$fonction,$nom){

	$creditCli = 0;
	$Commissions= 0;
	$max = 2147483647;
	$min = 1000000000;

	$value = rand($min, $max);
	$Num=substr($value,0,6);
    $id=(string)$Num;
   $connect=connexion();
   $activeGSM="non";
    $activeWEB="non";
   mysqli_set_charset($connect, "utf8");
   $accepter = "oui";
   $indicatifPays="00221";
   $Siege="Siege";
   $querySiege="select  telClient  from adherents where typeClient ='".$Siege."'";
   $resultSiege = mysqli_query($connect, $querySiege);
if(mysqli_num_rows($resultSiege) > 0 ) {
       while($resSiege = mysqli_fetch_array($resultSiege))
     {
       $numSiege=$resSiege['telClient'];
     }
}
	if ($numSiege==""){
	     return "";
		}


   $sql = "INSERT INTO adherents(nomClient,indicatifPays,telClient,creditClient,totalCommissions,Accepter,typeClient,agence,siege,paramWeb,paramGSM,dateInscription) VALUES
   ('$nom','$indicatifPays','$id','$creditCli','$Commissions','$accepter','$profil','$fonction','$numSiege','$activeWEB','$activeGSM',now());";

  if (!mysqli_query($connect ,$sql))

   {
	   echo mysqli_error($connect);
	    //echo '<script type="text/javascript">alert("Echec")</script>' ;
     return "";
    die('Error: ' . mysqli_error($connect));
   }
   else
  {
 // echo '<script type="text/javascript">alert("Ajout effectué")</script>' ;

	//$location="admin.php?section=user&page=unitList";
    //echo '<META HTTP-EQUIV="Refresh" Content="0; URL='.$location.'">';
	if ($profil=="Agence"){ $retour=ajout_horaire($nom,$Num);}
    return "succes";
  }

   mysqli_close($connect);



}

function ajout_horaire($nom,$num){
	$connect=connexion();

	for ($i=1; $i<=6; $i=$i+1)
    {
   switch ($i) {
    case "1":
	$Ouvert="08:00";
	$Fermer="17:00";
	$jour="Lundi";
	$sql = "INSERT INTO horaires(Entite,numEntite,jour,Ouvert,Fermer) VALUES ('$nom','$num','$jour','$Ouvert','$Fermer');";
        break;

		case "2":
	$Ouvert="08:00";
	$Fermer="17:00";
	$jour="Mardi";
	$sql = "INSERT INTO horaires(Entite,numEntite,jour,Ouvert,Fermer) VALUES ('$nom','$num','$jour','$Ouvert','$Fermer');";
        break;

		 case "3":
		$Ouvert="08:00";
	$Fermer="17:00";
	$jour="Mercredi";
	$sql = "INSERT INTO horaires(Entite,numEntite,jour,Ouvert,Fermer) VALUES ('$nom','$num','$jour','$Ouvert','$Fermer');";
        break;
		 case "4":
		$Ouvert="08:00";
	$Fermer="17:00";
	$jour="Jeudi";
	$sql = "INSERT INTO horaires(Entite,numEntite,jour,Ouvert,Fermer) VALUES ('$nom','$num','$jour','$Ouvert','$Fermer');";
	 break;
		 case "5":
	$Ouvert="08:00";
	$Fermer="18:00";
	$jour="Vendredi";
	$sql = "INSERT INTO horaires(Entite,numEntite,jour,Ouvert,Fermer) VALUES ('$nom','$num','$jour','$Ouvert','$Fermer');";
        break;

		 case "6":
	$Ouvert="08:00";
	$Fermer="12:00";
	$jour="Samedi";
	$sql = "INSERT INTO horaires(Entite,numEntite,jour,Ouvert,Fermer) VALUES ('$nom','$num','$jour','$Ouvert','$Fermer');";
        break;

    }
    if (!mysqli_query($connect ,$sql)) { }

   }

   mysqli_close($connect);
}
	?>
    </form>
</div>

<!-- Fenêtre de confirmation -->
<div class="modal" tabindex="-1" role="dialog" id="confirmation" style="margin-top:10%;">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background:">
            <h5 class="modal-title">Ajout d'une nouvelle unité organisationnelle</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true" style="color:white">&times;</span>
            </button>
      </div>
      <div class="modal-body">
        <p class="text-center" style="font-size:1.5em">Voulez-vous confirmer ?</p>
      </div>
      <div class="modal-footer">
        <input type="button" data-dismiss="modal" value="Non" >
        <!-- Si NON annuler l'ajout -->
        <input type="button" value="Oui" style="margin-right:35%">
        <!-- Si OUI valider le formulaire et ajout l'unité -->
      </div>
    </div>
  </div>
</div>

<form action="">
    <div class="modal" tabindex="-1" role="dialog" id="modifcaisse" style="margin-top:10%;">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
                <h5 class="modal-title">Modification de la caisse</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true" style="color:white">&times;</span>
                </button>
          </div>
          <div class="modal-body">
                <label>Désignation : </label>
                <input type="text" name="nom" value="">
          </div>
          <div class="modal-footer">
            <input type="button" data-dismiss="modal" value="Annuler" style="width:100px" >
            <!-- Si NON annuler l'ajout -->
            <input type="button" value="Valider" name="editerCaisse" style="margin-right:25%;width:100px">
            <!-- Si OUI valider le formulaire et ajout l'unité -->
          </div>
        </div>
      </div>
    </div>
</form>
<br>
<div class="row">
    <div class="col-md-12">
        <form action="" method="post">
            <fieldset style="width:700px">
                <legend>Filtres</legend>
                <div class="row">
                    <div class="col-md-2 mt-2">
                        <label for="fonction">Fonction : </label>
                    </div>
                    <div class="col-md-4">
                            <select name="cbofonction" id="fonction" class="styled-select">
							<option value="TOUS">TOUS</option>
                     		    <option value="Agence">AGENCE</option>
                            	<option value="backOffice">BACKOFFICE</option>
								<option value="Caisse">CAISSE</option>
								<option value="Distributeur">DISTRIBUTEUR</option>
                            </select>
                    </div>
                    <div class="col-md-2" style="margin-top:-15px">
                        <input type="submit" name='afficher' value='Afficher'>
                    </div>
                </div>
            </fieldset>
        </form>
    </div>
</div>
<br>
<div class="row">
    <div class="col-md-12">
        <table  class="gridtable" width='700' border='1'>
            <thead>
                <tr>

                    <td ><b>Login</b></td>
                    <td ><b>Libelle</b></td>


                    <td ><b>Fonction</b></td>
					<td ><b>Affectation</b></td>
                    <td ><b>Actions</b></td>
                </tr>
            </thead>
            <tbody>
              <!--  <tr>
                    <td>1234</td>
                    <td>log1234</td>
                    <td>BA</td>
                    <td>Alassane</td>
                    <td>Agence Foire</td>
                    <td>Administrateur</td>
                    <td class="text-center"><a href="admin.php?section=user&page=userEdit&id=5"><i class="fa fa-edit"></i></a></td>
                </tr>
                <tr>
                    <td>5678</td>
                    <td>log5678</td>
                    <td>DIALLO</td>
                    <td>Alioune Badara</td>
                    <td>Agence Parcelles</td>
                    <td>Supervisuer</td>
                    <td class="text-center"><a href="admin.php?section=user&page=userEdit&id=14"><i class="fa fa-edit"></i></a></td>
                </tr> -->
				<?php

				  if (ISSET($_POST['afficher'])) {

				    $connect=connexion();
                    mysqli_set_charset($connect, "utf8");
					$typ=$_POST['cbofonction'];
					$_SESSION['typ']=$typ;
					//echo $typ;
					if ($typ=="TOUS"){
						 $Agence="Agence";
					  $Caisse="Caisse";
					   $backoffice="backOffice";
					   $Distributeur="Distributeur";


					 $query="select  * from adherents where typeClient='".$Agence."' or typeClient='".$Caisse."' or typeClient='".$backoffice."' or typeClient='".$Distributeur."' order by nomClient ";

					}else
					{
						  $query="select  * from adherents where typeClient='".$typ."' order by nomClient ";
						  // echo $query;
					}

                    $result = mysqli_query($connect, $query);
					if(mysqli_num_rows($result) > 0 )
					{
					   while($res = mysqli_fetch_array($result))
					   {
							echo" <tr>";
							echo"<td align=center width='20'>".$res['telClient']."</td>";
							echo"<td align=center width='20'>".$res['nomClient']."</td>";
							echo"<td align=center width='20'>".$res['typeClient']."</td>";
							echo"<td align=center width='20'>".$res['agence']."</td>";
							//$location="admin.php?section=user&page=userList";
                           // echo '<META HTTP-EQUIV="Refresh" Content="0; URL='.$location.'">';
						   if ($res['typeClient']=="Agence"){
							  $action='<td class="text-center" width="5"><a href="admin.php?section=unite&page=uniteEditAgence&id='.$res['telClient'].'"><i class="fa fa-edit"></i></a></td>';
						   }else
						    if ($res['typeClient']=="Distributeur"){
							  $action='<td class="text-center" width="5"><a href="admin.php?section=unite&page=uniteEditDistrib&id='.$res['telClient'].'"><i class="fa fa-edit"></i></a></td>';
						   }else
						   {
							$action='<td class="text-center" width="5"><a href="admin.php?section=unite&page=userEditFiche&id='.$res['telClient'].'"><i class="fa fa-edit"></i></a></td>';
						   }
							echo $action;
							echo" </tr>";

					   }
					}
					 mysqli_close($connect);

				    }

				   else
					 {
 $connect=connexion();
					mysqli_set_charset($connect, "utf8");
						 $Agence="Agence";
					  $Caisse="Caisse";
					   $backoffice="backOffice";
					   $Distributeur="Distributeur";

					 $query="select  * from adherents where typeClient='".$Agence."' or typeClient='".$Caisse."' or typeClient='".$backoffice."' or typeClient='".$Distributeur."' order by dateInscription desc,nomClient ";
					 $result = mysqli_query($connect, $query);


					if(mysqli_num_rows($result) > 0 )
					{
					   while($res = mysqli_fetch_array($result))
					   {
							echo" <tr>";
							echo"<td align=center width='20'>".$res['telClient']."</td>";

						   echo"<td align=center width='20'>".$res['nomClient']."</td>";

							echo"<td align=center width='20'>".$res['typeClient']."</td>";
							echo"<td align=center width='20'>".$res['agence']."</td>";
							 if ($res['typeClient']=="Agence"){
							  $action='<td class="text-center" width="5"><a href="admin.php?section=unite&page=uniteEditAgence&id='.$res['telClient'].'"><i class="fa fa-edit"></i></a></td>';
						   }else
						    if ($res['typeClient']=="Distributeur"){
							  $action='<td class="text-center" width="5"><a href="admin.php?section=unite&page=uniteEditDistrib&id='.$res['telClient'].'"><i class="fa fa-edit"></i></a></td>';
						   }else
						   {
							$action='<td class="text-center" width="5"><a href="admin.php?section=unite&page=userEditFiche&id='.$res['telClient'].'"><i class="fa fa-edit"></i></a></td>';
						   }
							echo $action;
							echo" </tr>";

					   }
					}
					 mysqli_close($connect);
				   }

			    ?>
            </tbody>


            <tfoot>
                <tr>
                    <td colspan="7">
                        <nav aria-label="Page navigation example">
                            <ul class="pagination">
                                <li class="page-item">
                                    <a class="page-link" href="#" tabindex="-1"><i class="fa fa-angle-double-left"></i></a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="#">1</a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="#">2</a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="#">3</a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="#"><i class="fa fa-angle-double-right"></i></a>
                                </li>
                            </ul>
                        </nav>
                    </td>
                </tr>
            </tfoot>
        </table>
    </div>
</div>
