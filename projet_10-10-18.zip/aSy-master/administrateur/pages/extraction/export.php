<?php
    session_start();
    $data=$_SESSION['data'];
    $typ=$_SESSION['typ'];
    $FileName = $typ."-".date("d-m-Y").".xls";

    header("Content-type: application/msexcel; charset=UTF-8");
    header('Content-Disposition: attachment; filename="' . $FileName . '"');
    header("Pragma: no-cache");
    header("Expires: 0");

    echo ucwords($data)."\n";

?>
