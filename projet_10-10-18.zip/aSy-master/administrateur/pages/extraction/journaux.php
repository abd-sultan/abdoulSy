<?php
    include('inc/connexion.php');
?>
<div class="row">
    <div class="col-md-12">
        <form action="" method="post">
            <fieldset>
                <legend>Filtres</legend>
                <div class="row">
                    <div class="col-md-1">
                        <div class="">
                            <label for="fonction">Du : </label>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <input type="date" name="Du" value="<?php echo $_POST['Du']; ?>">
                    </div>
                    <div class="col-md-1">
                        <div class="">
                            <label for="fonction">Au : </label>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <input type="date" name="Au" value="<?php echo $_POST['Au']; ?>">
                    </div>
                    <div class="col-md-2 mt-2">
                        <?php
                        $connect = connexion();
                        $typeA="Agence";
                        $queryAgence="select  telClient,nomClient from adherents where typeClient='". $typeA."'  order by nomClient ";
                        $result = mysqli_query($connect, $queryAgence);
                         echo '<select name="cboagence" class="styled-select" >';
                         echo '<option  value="'."TOUS".'">'."TOUS".'</option>';
                        if(mysqli_num_rows($result) > 0 )
                            {
                              while ($row = mysqli_fetch_assoc($result))
                               {
                                 echo '<option  value="'.$row['telClient']."-".$row['nomClient'].'" class="select-it">'.$row['telClient']."-".$row['nomClient'].'</option>';
                               }
                               echo '</select>';
                             }
                            mysqli_close($connect);
                         ?>
                     </div>
                     <div class="col-md-2 mt-2">
                         <input type="submit" name="exporter" value="EXPORT" style="margin-top:-10px">
                     </div>
                </div>
            </fieldset>
        </form>
    </div>
</div>
<?php
if (ISSET($_POST['exporter'])) {
$tel=$_SESSION['numero'];

$connect = connexion();

if(mysqli_connect_errno())
{
echo 'Connexion au serveur MySQL a echoue:';
}
else
{
mysqli_set_charset($connect, "utf8");
$_SESSION['Du'] = $_POST['Du'];
$_SESSION['Au'] = $_POST['Au'];
$from=$_POST['Du'];
$to=$_POST['Au'];
$from=str_replace("/","-",$from);
$to=str_replace("/","-",$to);
$connect = connexion();
$csv_export = "";
$tel=$_SESSION['numero'];
$annule="Annule";
$status="envoie";
$sType="Transferts";
$query="select  *  from commisions where Type='".$sType."'";
$result = mysqli_query($connect, $query);
$temp_array = array();
while($res = mysqli_fetch_array($result))
{
    $pourcentage = $res['Emetteur'] / 100;
}
$agence=$_POST['cboagence'];
if ($agence=="TOUS"){
    $agenceChoix=$agence;
    $query="select  refEmetteur,sum(Montant) as montant,sum(fraisTransaction *".$pourcentage.") as commission,date(dateTransaction) as dat,time(dateTransaction) as heure,fraisTransaction,telEmetteur,SousDistrib  from transactions where status <>'". $annule . "' and date(dateCloture) between '".$from."' and '".$to."' group by dateTransaction desc,telEmetteur";
}
else {
    $sagence = explode("-", $agence);
    $agenceChoix=$sagence[0];
    $query="select  refEmetteur,sum(Montant) as montant,sum(fraisTransaction *".$pourcentage.") as commission,date(dateTransaction) as dat,time(dateTransaction) as heure,fraisTransaction,telEmetteur,SousDistrib  from transactions where numagence='". $agenceChoix."' and status <>'". $annule . "' and date(dateCloture) between '".$from."' and '".$to."' group by dateTransaction desc,telEmetteur";

}
$result = mysqli_query($connect, $query);
$columnHeader ='';
$columnHeader = "Ref"."\t"."Beneficiaire"."\t"."Montant"."\t"."fraisTransaction"."\t"."Commission"."\t"."Date"."\t"."Heure"."\t"."numcaisse"."\t";
if(mysqli_num_rows($result) > 0 ) {
    while($res = mysqli_fetch_array($result)) {
        //$result = mysqli_query($connect, $query);
        $temp_array["refEmetteur"]= $res['refEmetteur'];
        $temp_array["Beneficiaire"]= $res['telEmetteur'];
        $temp_array["Montant"]= $res['montant'];
        $temp_array["fraisTransaction"]= $res['fraisTransaction'];
        $temp_array["Commission"]=$res['commission'];
        $temp_array["Date"]=$res['dat'];
        $temp_array["Heure"]=$res['heure'];
        $temp_array["numcaisse"]=$res['SousDistrib'];
        $refEmetteur=$temp_array['refEmetteur'];
       $csv_export.= $temp_array['refEmetteur']."\t".$temp_array['Beneficiaire']."\t".$temp_array['Montant']."\t".$temp_array['fraisTransaction']."\t".$temp_array['Commission']."\t".$temp_array['Date']."\t".$temp_array['Heure']."\t".$temp_array['numcaisse']."\n";
   }
   $_SESSION['data'] = ucwords($columnHeader)."\n".$csv_export."\n";
    $_SESSION['typ']= "Emissions";
    //  $FileName = "Emission-".date("d-m-Y").".xls";
    //
    // header("Content-type: application/octet-stream");
    // header('Content-Disposition: attachment; filename="' . $FileName . '"');
    // header("Pragma: no-cache");
    // header("Expires: 0");
    //
    // echo ucwords($data)."\n";
    $location="pages/extraction/export.php";
    echo '<META HTTP-EQUIV="Refresh" Content="0; URL='.$location.'">';
    // include('pages/extraction/export.php');
    // header('location: export.php');
} // end if mysqli_num_rows($resultCl) > 0
else {
    echo 'Aucune donnée pour la requête';
}
mysqli_close($connect);
}
}
?>
