<div class="container">
        <form action="" method="post">
            <fieldset class="ml-5 py-0 my-0" style="width:700px;padding:0">
                <legend style="height:30px;font-size:1em">Rapport de Fin de Journée</legend>
                <div class="form-group">
                    <div class="row">
                        <div class="col-md-2 mt-3 offset-md-1">
                            <label>Journée</label>
                        </div>
                        <div class="col-md-4">
                            <input type="date" name="jour" value="<?php echo $_POST['jour'] ?>">
                        </div>
                        <div class="col-md-3">
                            <input type="submit" name="submit" value="Visualiser">
                        </div>
                    </div>
                </div>
            </fieldset>
        </form>
        <table class="gridtable ml-5 mt-2" width='700' border='1'>

 <?php


     if (isset($_POST['submit'])){
		$from=$_POST['jour'];

		$from=str_replace("/","-",$from);
		 $CommissionSupportee=0;
          $CommissionCompteSamba=0;


		affichage_commission_supportee($from);
		affichage_commission_collecte($from);
	 }


	 function affichage_commission_supportee($from){

$host_name = 'localhost';
 $database = 'compte_samba';
 $user_name = 'root';
 $password = '';
 $TransfEmis="0";
		$TransfRecu="0";
		$Retrait="0";
		$totalEncaissement="0";
		$totalDecaissement="0";

$csv_export="";
   $annule="Annule";
 $etat="Clôturée";
  global $connect;
  global  $CommissionSupportee;
   global $CommissionCompteSamba;
//and status <>'". $annule . "
 $connect = mysqli_connect($host_name, $user_name, $password, $database);
mysqli_set_charset($connect, "utf8");
 if(mysqli_connect_errno())
 {
 echo 'Connexion au serveur MySQL a echoue:';
 }
 else
 {

$temp_array = array();
   $usersList_array =array();


   $from=date('d-m-Y',strtotime($from));




   $indice=0;
$pourcentage=0;
       $pourcentageEmmeteur=0;
	   $pourcentageCompteSamba=0;
	  $commissionCompteSambaTransfert=0;
	   $commissionCompteSambaEmis=0;
	  $commissionCompteSambaRetrait=0;

       $TransfRecu=0;
       $TransfEmis=0;
       $Retrait=0;
	   $Total=0;
       $pourcentageEm=0;

	   $type="Distributeur";
   $queryDistrib="select  nomClient,telClient  from adherents where typeClient ='".$type."' order by nomClient";

   //echo $query;
   $resultCl = mysqli_query($connect, $queryDistrib);




 if(mysqli_num_rows($resultCl) > 0 ) {
       while($resCl = mysqli_fetch_array($resultCl))
       {

       $annule="Annule";
       $etat="Clôturée";
       $nomPrenom=$resCl['nomClient'];
	   $numDistrib=$resCl['telClient'];
       $sType="Transferts";
        $query="select  *  from commisions where Type='".$sType."'";
        $result = mysqli_query($connect, $query);
        while($res = mysqli_fetch_array($result))
         {
		   $pourcentage=$res['Recepteur'] / 100;
          $pourcentageEmmeteur=$res['Emetteur'] / 100;
         $pourcentageCompteSamba=$res['CompteSamba'] / 100;
         }

		  $query="select  sum(Montant) as frais,sum(fraisTransaction *".$pourcentage.") as commission,dateCloture,telRecepteur  from transactions where numcaissecloture ='".$numDistrib."' and status <>'". $annule . "' and date(dateCloture)=STR_TO_DATE('$from','%d-%m-%Y') ";
    $result = mysqli_query($connect, $query);
    if(mysqli_num_rows($result) > 0 ) {
       while($res = mysqli_fetch_array($result))
       {
        $TransfRecu=$res['commission'];

       }

    }

	//-----------------


    $query="select  sum(Montant+fraisTransaction) as montant,sum(fraisTransaction *".$pourcentageEmmeteur.") as commission,sum(fraisTransaction *".$pourcentageCompteSamba.") as commissionCompteSambaTransfert,dateTransaction,telEmetteur  from transactions where numcaisse='". $numDistrib."' and status <>'". $annule . "' and date(dateTransaction)=STR_TO_DATE('$from','%d-%m-%Y')";
    $result = mysqli_query($connect, $query);
    if(mysqli_num_rows($result) > 0 ) {
       while($res = mysqli_fetch_array($result))
       {
        $TransfEmis=$res['commission'];
		$commissionCompteSambaTransfert=$res['commissionCompteSambaTransfert'];
		//echo $TransfEmis;
       }

    }

	//-----------------Retrait--------------------
	// recupere le % des commisions
		$sType="Retraits";
        $query="select  *  from commisions where Type='".$sType."'";
        $result = mysqli_query($connect, $query);
        while($res = mysqli_fetch_array($result))
         {
		   $pourcentageEm=$res['Emetteur'] / 100;
           $pourcentageCompteSambaRetrait=$res['CompteSamba'] / 100;
         }
		 //echo $pourcentage;
$typOp="Retrait";
$status="Accepte";
$query="select  sum(Montant-fraisRetrait) as total,sum(fraisRetrait *".$pourcentageEm.") as
commission,sum(fraisRetrait *".$pourcentageCompteSambaRetrait.") as
commissionCompteSambaRetrait,telEmetteur,Montant,dateTransaction from transferts where telRecepteur ='". $numDistrib."' and typeOperation='".$typOp."' and date(dateTransaction)=STR_TO_DATE('$from','%d-%m-%Y')  and status='".$status."'";
 $result = mysqli_query($connect, $query);
    if(mysqli_num_rows($result) > 0 ) {
       while($res = mysqli_fetch_array($result))
       {
        $Retrait=$res['commission'];
		$commissionCompteSambaRetrait=$res['commissionCompteSambaRetrait'];
       }

    }








	$Total=$TransfRecu+$TransfEmis+$Retrait;
	$CommissionSupportee=$CommissionSupportee+$Total;

	$CommissionCompteSamba=$CommissionCompteSamba+$commissionCompteSambaTransfert+$commissionCompteSambaRetrait;



	   $indice=$indice+1;



	   }
 }
//echo $CommissionSupportee. "  -  ".$CommissionCompteSamba;
	 mysqli_close($connect);

 }

  // echo $CommissionSupportee;

 }

 function affichage_commission_collecte($from){


 $host_name = 'localhost';
 $database = 'compte_samba';
 $user_name = 'root';
 $password = '';
  $connect = mysqli_connect($host_name, $user_name, $password, $database);
			 mysqli_set_charset($connect, "utf8");

			  $typ="Siege";
    $query="select  *  from adherents where typeClient ='".$typ."'";


    $result = mysqli_query($connect, $query);
		if(mysqli_num_rows($result) > 0 ) {
       while($res = mysqli_fetch_array($result))
       {
       // echo "succes" ;
		$tel=$res['telClient'];

       }
		}


echo '<br>';


$from=date("d-m-Y",strtotime($from));

$TransfRecu=0;
$TransfEmis=0;
$Retrait=0;
$totalEncaissement=0;
$totalDecaissement=0;
$commissionCompteSambaRetrait=0;
$commissionCompteSambaTransfert=0;
$CommissionCollectee=0;
global $CommissionCompteSamba;
global $CommissionSupportee;
			  $annule="Annule";
 $etat="Clôturée";
//and status <>'". $annule . "'
$sType="Transferts";
        $query="select  *  from commisions where Type='".$sType."'";
        $result = mysqli_query($connect, $query);
        while($res = mysqli_fetch_array($result))
         {
		   $pourcentage=$res['Recepteur'] / 100;
          $pourcentageEmmeteur=$res['Emetteur'] / 100;
          $pourcentageCompteSamba=$res['CompteSamba'] / 100;
         }





		$query="select  sum(Montant) as total,sum(fraisTransaction *".$pourcentage.") as commission,dateTransaction,telRecepteur  from transactions where numsiegecloture ='". $tel."' and status <>'". $annule . "'  and date(dateCloture)=STR_TO_DATE('$from','%d-%m-%Y') ";


    $result = mysqli_query($connect, $query);
    if(mysqli_num_rows($result) > 0 ) {
       while($res = mysqli_fetch_array($result))
       {
        $TransfRecu=$res['commission'];
        $totalDecaissement=$res['total'];

       }

    }



		   $query="select  sum(Montant+fraisTransaction) as montant,sum(fraisTransaction *".$pourcentageEmmeteur.") as commission,sum(fraisTransaction *".$pourcentageCompteSamba.") as commissionCompteSambaTransfert,dateTransaction,telEmetteur  from transactions where numsiege='". $tel."' and status <>'". $annule . "' and date(dateTransaction)=STR_TO_DATE('$from','%d-%m-%Y') ";



	$result = mysqli_query($connect, $query);
    if(mysqli_num_rows($result) > 0 ) {
       while($res = mysqli_fetch_array($result))
       {
        $TransfEmis=$res['commission'];
        $totalEncaissement=$res['montant'];
		$commissionCompteSambaTransfert=$res['commissionCompteSambaTransfert'];
		//echo $TransfEmis;
       }

    }

	//-----------------Retrait--------------------
	// recupere le % des commisions
		$sType="Retraits";
        $query="select  *  from commisions where Type='".$sType."'";
        $result = mysqli_query($connect, $query);
        while($res = mysqli_fetch_array($result))
         {
		   $pourcentageEm=$res['Emetteur'] / 100;
 $pourcentageCompteSambaRetrait=$res['CompteSamba'] / 100;
         }
		 //echo $pourcentage;
$typOp="Retrait";
$status="Accepte";

	 $query="select  sum(Montant-fraisRetrait) as total,sum(fraisRetrait *".$pourcentageEm.") as
commission,sum(fraisRetrait *".$pourcentageCompteSambaRetrait.") as
commissionCompteSambaRetrait,telEmetteur,Montant,dateTransaction from transferts where numsiege ='". $tel."' and typeOperation='".$typOp."' and date(dateTransaction)=STR_TO_DATE('$from','%d-%m-%Y')  and status='".$status."'";


 $result = mysqli_query($connect, $query);
    if(mysqli_num_rows($result) > 0 ) {
       while($res = mysqli_fetch_array($result))
       {
        $Retrait=$res['commission'];
		$commissionCompteSambaRetrait=$res['commissionCompteSambaRetrait'];
	   $totalDecaissement=$totalDecaissement+$res['total'];
       }

    }
//------Recharge-------------------

$typOp="Recharge";

$query="select  sum(Montant) as total,sum(fraisRetrait *".$pourcentage.") as commission,Montant,dateTransaction,telRecepteur from transferts where numsiege ='". $tel."' and status='".$status."' and typeOperation='".$typOp."' and date(dateTransaction)=STR_TO_DATE('$from','%d-%m-%Y')";


$result = mysqli_query($connect, $query);
    if(mysqli_num_rows($result) > 0 ) {
       while($res = mysqli_fetch_array($result))
       {

	$totalEncaissement=$totalEncaissement+$res['total'];
       }

    }

	 $CommissionCollectee=$TransfEmis+$TransfRecu+$Retrait;
	 $CommissionCompteSamba=$CommissionCompteSamba+$commissionCompteSambaTransfert+$commissionCompteSambaRetrait;
	  $MouvemenNetGuichet=$totalEncaissement-$totalDecaissement;
	//echo $CommissionCompteSamba. " - ".$commissionCompteSambaTransfert. " - ". $CommissionCollecte;






  $TransfEmis = number_format($TransfEmis, 0, ',', ' ');
  $TransfRecu = number_format($TransfRecu, 0, ',', ' ');
  $Retrait = number_format($Retrait, 0, ',', ' ');
  $totalEncaissement = number_format($totalEncaissement, 0, ',', ' ');
  $totalDecaissement = number_format($totalDecaissement, 0, ',', ' ');




  echo "<br /> ";
	  mysqli_close($connect);



  echo" <tr>";
       echo"<td align=left width='300'><b>RUBRIQUES</td></b>";
       echo"<td align=right width='300'><b>MONTANTS</td></b>";



   echo'</tr>';
 echo"<tr with='600'>";
 echo"<td align=left width='300'>"."Commissions Collectées"."</td>";
  echo"<td align=right width='300'>"."-".number_format($CommissionCollectee, 0, ',', ' ')."</td>";
  echo"</tr>";
  echo"<tr with='600'>";
  echo"<td align=left width='300'>"."Commissions Supportées"."</td>";
  echo"<td align=right width='300'>".number_format($CommissionSupportee, 0, ',', ' ')."</td>";
   echo"</tr>";
	 echo"<tr with='600'>";
  echo"<td align=left width='300'>"."Charges marketing"."</td>";
  echo"<td align=right width='300'>"."-".number_format(($CommissionCollectee+$CommissionSupportee)*0.05, 0, ',', ' ')."</td>";
   echo"</tr>";
    echo"</tr>";
	 echo"<tr with='600'>";
  echo"<td align=left width='300'>"."Taxes Collectées"."</td>";
  echo"<td align=right width='300'>"."-".number_format(($CommissionCollectee)*0.17, 0, ',', ' ')."</td>";
   echo"</tr>";
    echo"<tr with='600'>";
  echo"<td align=left width='300'>"."Taxes Supportées"."</td>";
  echo"<td align=right width='300'>"."-".number_format(($CommissionSupportee)*0.17, 0, ',', ' ')."</td>";
   echo"</tr>";
	 echo"</tr>";
    echo"<tr with='600'>";
  echo"<td align=left width='300'>".""."</td>";
   echo"<td align=left width='300'>".""."</td>";
    echo"</tr>";
  echo"</tr>";
  echo"<tr with='600'>";
  echo"<td align=left width='300'>".""."</td>";
   echo"<td align=left width='300'>".""."</td>";
    echo"</tr>";
      echo"<tr with='600'>";
  echo"<td align=left width='300'>"."Commissions System"."</td>";
  echo"<td align=right width='300'>"."-".number_format($CommissionCompteSamba, 0, ',', ' ')."</td>";
   echo"</tr>";
        echo"</tr>";
      echo"<tr with='600'>";
  echo"<td align=left width='300'>"."Mouvement Net Guichets"."</td>";
  echo"<td align=right width='300'>"."-".number_format($MouvemenNetGuichet, 0, ',', ' ')."</td>";
   echo"</tr>";
    echo'</tr>';
 }
?>


	</td>
</tr>
        </table>
</div>
