<?php
    include('inc/connexion.php');
?>
<div class="row">
    <div class="col-md-12">
        <form action="" method="post">
            <fieldset>
                <legend>Filtres</legend>
                <div class="row">
                    <div class="col-md-1">
                        <div class="">
                            <label for="fonction">Du : </label>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <input type="date" name="Du" value="<?php echo $_SESSION['Du']; ?>">
                    </div>
                    <div class="col-md-1">
                        <div class="">
                            <label for="fonction">Au : </label>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <input type="date" name="Au" value="<?php echo $_SESSION['Au']; ?>">
                    </div>
                    <div class="col-md-2 mt-2">
                            <?php
                            $connect = connexion();
                            $typeD="Distributeur";
                            $queryDistrib="select  telClient,nomClient from adherents where typeClient='". $typeD."'  order by nomClient ";
                            $result = mysqli_query($connect, $queryDistrib);
                             echo '<select name="cbodistrib" class="styled-select" >';
                             echo '<option  value="'."TOUS".'">'."TOUS".'</option>';
                               if(mysqli_num_rows($result) > 0 )
                                {
                                  while ($row = mysqli_fetch_assoc($result))
                                   {
                                     echo '<option  value="'.$row['telClient']."-".$row['nomClient'].'">'.$row['telClient']."-".$row['nomClient'].'</option>';
                                   }
                                   echo '</select>';
                                 }
                                mysqli_close($connect);
                             ?>
                         </div>
                         <div class="col-md-2 mt-2">
                             <input type="submit" name="afficher" value="Afficher" style="margin-top:-10px">
                         </div>
                </div>
            </fieldset>
        </form>
    </div>
</div>
<div  align="center" class="container">
            <!-- zone de connexion -->
<center>

<tr>
<td align=left>
<br>
<br>
 <?php

    if (ISSET($_POST['afficher'])) {
        $_SESSION['Du'] = $_POST['Du'];
		$_SESSION['Au'] = $_POST['Au'];

        $stel="20032003";

		$from=$_SESSION['Du'];
		$to=$_SESSION['Au'];
        // $from = "01/06/2018";
        // $to = "09/10/2018";
		$from=str_replace("/","-",$from);
		$to=str_replace("/","-",$to);

		$TransfEmis="0";
		$TransfRecu="0";
		$Retrait="0";
		$totalEncaissement="0";
		$totalDecaissement="0";

		affichage($from,$to);

}

function affichage($from,$to){

$host_name = 'localhost';
 $database = 'compte_samba';
 $user_name = 'root';
 $password = '';


$csv_export="";
   $annule="Annule";
 $etat="Clôturée";
  global $connect;
//and status <>'". $annule . "
 $connect = mysqli_connect($host_name, $user_name, $password, $database);
mysqli_set_charset($connect, "utf8");
 if(mysqli_connect_errno())
 {
 echo 'Connexion au serveur MySQL a echoue:';
 }
 else
 {

$temp_array = array();
   $usersList_array =array();
   $dateToday=date('d-m-Y', strtotime('+0 days'));

   $from=date('Y-m-d',strtotime($from));
   $to=date('Y-m-d',strtotime($to ));


   $type="Distributeur";
   $indice=0;
   //echo $_POST['cbodistrib'];
   $numDist = $_POST['cbodistrib'];
   $n = explode("-",$numDist);
   //echo $n[0];
   if ($n[0] == "TOUS") {
       $queryDistrib="select  nomClient,telClient  from adherents where typeClient ='".$type."' order by nomClient";
   } else {
       //$dist = explode("-",$_POST['cbodistrib']);
       $queryDistrib="select  nomClient,telClient  from adherents where typeClient ='".$type."' AND telClient ='".$n[0]."'";
       //echo $dist = explode("-",$_POST['cbodistrib'])[0];
       //echo $queryDistrib;
   }



  // nomClient=$_POST['cbDistrib'];

   //echo $query;
   $resultCl = mysqli_query($connect, $queryDistrib);
   echo "<td align=center> Du : ".date("d-m-Y",strtotime($from))."  Au : ". date("d-m-Y",strtotime($to));
echo '<br>';
echo '<br>';

		echo "<table  class='gridtable' border='1'>";
  echo' <tr>';
       echo"<td align=left width='200'><b>Distributeur</td></b>";
       echo"<td align=center width='100'><b>Numero</b></td>";
       echo"<td align=right width='80'><b>Emission</b></td>";
       echo"<td align=right width='80'><b>Réception</b></td>";
	     echo"<td align=right width='100'><b>Retrait</b></td>";
   echo'</tr>';
$csv_export.= "Distributeur".","."Numero".","."Emission".","."Réception".","."Retrait".","."Total"."\n";

 if(mysqli_num_rows($resultCl) > 0 ) {
       while($resCl = mysqli_fetch_array($resultCl))
       {
		$pourcentage=0;
       $pourcentageEmmeteur=0;
       $TransfRecu="0";
       $TransfEmis="0";
       $Retrait="0";
	   $Total=0;
       $pourcentageEm=0;

       $annule="Annule";
       $etat="Clôturée";
       $nomPrenom=$resCl['nomClient'];
	   $numDistrib=$resCl['telClient'];
       $sType="Transferts";
        $query="select  *  from commisions where Type='".$sType."'";
        $result = mysqli_query($connect, $query);
        while($res = mysqli_fetch_array($result))
         {
		   $pourcentage=$res['Recepteur'] / 100;
          $pourcentageEmmeteur=$res['Emetteur'] / 100;
         }
		  $query="select  sum(Montant) as frais,sum(fraisTransaction *".$pourcentage.") as commission,dateCloture,telRecepteur  from transactions where numcaissecloture ='".$numDistrib."' and status <>'". $annule . "' and date(dateCloture) between '$from' and '$to'";
    $result = mysqli_query($connect, $query);
    if(mysqli_num_rows($result) > 0 ) {
       while($res = mysqli_fetch_array($result))
       {
        $TransfRecu=$res['commission'];
       }

    }

	//-----------------


    $query="select  sum(Montant+fraisTransaction) as montant,sum(fraisTransaction *".$pourcentageEmmeteur.") as commission,dateTransaction,telEmetteur  from transactions where numcaisse='". $numDistrib."' and status <>'". $annule . "' and date(dateTransaction) between '$from' and '$to'";
    $result = mysqli_query($connect, $query);
    if(mysqli_num_rows($result) > 0 ) {
       while($res = mysqli_fetch_array($result))
       {
        $TransfEmis=$res['commission'];
		//echo $TransfEmis;
       }

    }

	//-----------------Retrait--------------------
	// recupere le % des commisions
		$sType="Retraits";
        $query="select  *  from commisions where Type='".$sType."'";
        $result = mysqli_query($connect, $query);
        while($res = mysqli_fetch_array($result))
         {
		   $pourcentageEm=$res['Emetteur'] / 100;
         }
		 //echo $pourcentage;
$typOp="Retrait";
$status="Accepte";
$query="select  sum(Montant-fraisRetrait) as total,sum(fraisRetrait *".$pourcentageEm.") as
commission,telEmetteur,Montant,dateTransaction from transferts where telRecepteur ='". $numDistrib."' and typeOperation='".$typOp."' and date(dateTransaction) between '$from' and '$to'  and status='".$status."'";
 $result = mysqli_query($connect, $query);
    if(mysqli_num_rows($result) > 0 ) {
       while($res = mysqli_fetch_array($result))
       {
        $Retrait=$res['commission'];

       }

    }







    $TotalTransf=$TransfRecu+$TransfEmis;
	$Total=$TotalTransf+$Retrait;

	$temp_array['Distributeur']=$nomPrenom;
	$temp_array['Numero']=$numDistrib;
	$temp_array['Reception']=$TransfRecu;
    $temp_array['Emission']=$TransfEmis;
	$temp_array['Retrait']=$Retrait;
	$temp_array['Total']=$Total;

  //echo $TotalTransf."-".$Retrait;

	   echo'<tr>';

        echo"<td align=left width='200'>".$temp_array['Distributeur']."</td>";
       echo"<td align=center width='100'>".$temp_array['Numero']."</td>";
       echo"<td align=right width='80'>".$temp_array['Emission']."</td>";
       echo"<td align=right width='80'>".$temp_array['Reception']."</td>";
	     echo"<td align=right width='100'>".$temp_array['Retrait']."</td>";

    echo'</tr>';
	   $indice=$indice+1;
	   $csv_export.= $temp_array['Distributeur'].",".$temp_array['Numero'].",".$temp_array['Emission'].",".$temp_array['Emission'].",".$temp_array['Retrait']."\n";



	   }
 }
	 mysqli_close($connect);
	  $_SESSION['data']= $csv_export;
     $_SESSION['typ']= "CommissionsDistributeurs";
 }


 }


?>



</td>
</tr>

</center>
  </div>
    </body>
</html>
