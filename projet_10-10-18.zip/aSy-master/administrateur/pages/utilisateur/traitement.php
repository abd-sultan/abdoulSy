
<?php

 $connect=connexion();


if (ISSET($_POST['submit'])) {
    $nom = $_POST['nom'];
    $fonction = $_POST['cbofonction'];
    $agence = $_POST['cboagence'];
	$nom=$_POST['nom'];
	$prenom=$_POST['prenom'];
	$adresse=$_POST['adresse'];
	$tel=$_POST['tel'];
	$email=$_POST['email'];
	$cellulaire=$_POST['cellulaire'];
	$password=$_POST['password'];
	
	$pin=$_POST['code'];
	
	
if (isset($_POST['profil'])){
    	$profil = $_POST['profil'];
}
	switch ($profil) {
    case "Controleur":
	$fonction="";
        $retour=ajout_compte($profil,$fonction,$nom,$prenom,$adresse,$tel,$email,$cellulaire,$password,$pin);
        break;
    case "Agence":
	 ajout_affectation($profil,$fonction);
        break;
    case "backOffice":
	ajout_affectation($profil,$fonction);
        break;
	case "Distributeur":
	$fonction="";
      $retour= ajout_compte($profil,$fonction,$nom,$prenom,$adresse,$tel,$email,$cellulaire,$password,$pin);
        break;
     }

  //  echo "Profil : ". $profil . " Nom : ".$nom." Fonction : ".$fonction." Agence : ".$agence;
   // echo Profil: '. $profil.' Nom : '. $nom .' Fonction: '. $fonction.' Agence : '. $agence;
    //header("Location: ./userList.php");
	
}


function ajout_compte($profil,$fonction,$nom,$prenom,$adresse,$tel,$email,$cellulaire,$password,$pin){
	
	$creditCli = 0;
	$Commissions= 0;
	$max = 2147483647;
	$min = 1000000000;

	$value = rand($min, $max);	
	$Num=substr($value,0,6);
    $id=(string)$Num;
   global $connect;
   mysqli_set_charset($connect, "utf8"); 
   $accepter = "oui";
   $indicatifPays="00221";
   $Siege="Siege";
   $querySiege="select  telClient  from adherents where typeClient ='".$Siege."'";
   $resultSiege = mysqli_query($connect, $querySiege);
if(mysqli_num_rows($resultSiege) > 0 ) {
       while($resSiege = mysqli_fetch_array($resultSiege))
     {
       $numSiege=$resSiege['telClient'];
     }
}	   
	if ($numSiege==""){
	     return "";
		}
		$prenomNom=$prenom. " ". $nom ;
   $sql = "INSERT INTO adherents(nom,prenom,nomClient,indicatifPays,telClient,passwordClient,pinClient,adresse,mailClient,telfixe,celullaire,creditClient,totalCommissions,Accepter,typeClient,siege,dateInscription) VALUES 
   ('$nom','$prenom','$prenomNom','$indicatifPays','$id','$password','$pin','$adresse','$mail','$tel','$cellulaire','$creditCli','$Commissions','$accepter','$profil','$numSiege',now());";  
 
  if (!mysqli_query($connect ,$sql))
   {
     return "";
    die('Error: ' . mysqli_error($connect));
   }   
   else
  {
  echo '<script type="text/javascript">alert("Ajout effectué")</script>' ;
    return "succes";
  }  
   mysqli_close($connect);
 


}
?>