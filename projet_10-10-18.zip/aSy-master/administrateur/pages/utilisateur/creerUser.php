<?php

 include('inc/connexion.php');


 $connect=connexion();
 mysqli_set_charset($connect, "utf8");
  $type="Siege";
 $query="select  telClient,nomClient from adherents where typeClient='". $type."'";
  $result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0 )
 {
   while ($row = mysqli_fetch_assoc($result))
	{
	  $Siege=$row['nomClient'];
	}
  }
 $type="Agence";
 $query="select  telClient,nomClient from adherents where typeClient='". $type."'  order by nomClient ";
 $result = mysqli_query($connect, $query);

 $typeD="Distributeur";
 $queryDistrib="select  telClient,nomClient from adherents where typeClient='". $typeD."'  order by nomClient ";
 $resultDistrib = mysqli_query($connect, $queryDistrib);

  mysqli_close($connect);

?>


<div class="container">
    <form action="#" method="post" name="form_generatites" id="form_generatites">
        <fieldset>
            <legend class="text-center">Généralités</legend>
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="nom">Nom <span style="color: red;">*</span></label>
                        <input type="text"  placeholder="nom" name="nom" id="nom"  value="<?php echo $_SESSION['nom'];?>" required />
                    </div>
                    <div class="form-group">
                        <label for="adresse">Adresse</label>
                        <input type="text" class="form-control form-control-sm" placeholder="adresse" name="adresse" id="adresse" value="<?php echo $_SESSION['adresse'];?>" />
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="prenom">Prénom</label>
                        <input type="text" class="form-control form-control-sm" placeholder="prénom" name="prenom" id="prenom" value="<?php echo $_SESSION['prenom'];?>" required />
                    </div>
                    <div class="form-group">
                        <label for="tel">Téléphone</label>
                        <input type="text" class="form-control form-control-sm" placeholder="téléphone" name="tel" id="tel" pattern="[0-9]{9}" title="maximum 9 chiffres" onkeypress='return event.charCode >= 48 &&   event.charCode <= 57 ||    event.charCode == 46'  value="<?php echo $_SESSION['tel'];?>" required />
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control form-control-sm" placeholder="email" name="email" id="email" value="<?php echo $_SESSION['email'];?>"/>
                    </div>
                    <div class="form-group">
                        <label for="cellulaire">Cellulaire</label>
                        <input type="tel" class="form-control form-control-sm" placeholder="cellulaire" name="cellulaire" id="cellulaire" value="<?php echo $_SESSION['cellulaire'];?>" pattern="[0-9]{9}" title="maximum 9 chiffres" onkeypress='return event.charCode >= 48 &&   event.charCode <= 57 ||    event.charCode == 46' />
                    </div>
                </div>
            </div>
        </fieldset>
        <!-- --> <br><br>
        <div class="row">
            <div class="col-md-6">
                <fieldset>
                    <legend class="text-center">Paramètres web</legend>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-5">
                                <label for="password">Mot de passe</label>
                            </div>
                            <div class="col-md-7">
                                <input type="text" class="form-control form-control-sm" placeholder="Mot de passe" name="password" value="<?php echo $_SESSION['password'];?>" pattern="[0-9]{4}" title="maximum 4 chiffres" onkeypress='return event.charCode >= 48 &&   event.charCode <= 57 ||    event.charCode == 46' id="password"/>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-5">
                                <label for="number">Confirmez le mot de passe</label>
                            </div>
                            <div class="col-md-7">
                                <input type="text" class="form-control form-control-sm" placeholder="Répétez le mot de passe" name="password2" id="password2" value="<?php echo $_SESSION['password2'];?>" pattern="[0-9]{4}" title="maximum 4 chiffres" onkeypress='return event.charCode >= 48 &&   event.charCode <= 57 ||    event.charCode == 46' />
                            </div>
                        </div>
                    </div>
                </fieldset>
            </div>
            <div class="col-md-6">
                <fieldset>
                    <legend class="text-center">Paramètres GSM</legend>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-5">
                                <label for="code">Code PIN</label>
                            </div>
                            <div class="col-md-7">
                                <input type="text" class="form-control form-control-sm" placeholder="Code PIN" name="code" id="code" value="<?php echo $_SESSION['code'];?>"  pattern="[0-9]{6}" title="maximum 6 chiffres" onkeypress='return event.charCode >= 48 &&   event.charCode <= 57 ||    event.charCode == 46'/>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-5">
                                <label for="code2">Confirmez le code PIN</label>
                            </div>
                        <div class="col-md-7">
                            <input type="text" class="form-control form-control-sm" placeholder="Répétez le code PIN" name="code2" id="code2" value="<?php echo $_SESSION['code2'];?>" pattern="[0-9]{6}" title="maximum 6 chiffres" onkeypress='return event.charCode >= 48 &&   event.charCode <= 57 ||    event.charCode == 46' />
                        </div>
                    </div>
                </fieldset>
            </div>
        </div>
        <!-- --> <br><br>


					<input type="button" id="btn-ajouter" data-toggle="modal" data-target="#affectations"  value='AFFECTER'>
                <div class="col-md-4"></div>
            </div>
            <div class="modal fade" tabindex="-1" role="dialog" id="affectations" area-labelledby="affectations" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" class="text-center">Choisir une affectation</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <i class="fa fa-times-circle" style="color:white"></i>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                    <ul>

										<li>
										<INPUT type= "radio" name="profil" value="Controleur" required> CONTROLEUR
										</li>
										<li><INPUT type= "radio" name="profil" value="Agence" required> AGENCE
                                        <ul>
                                            <li>
                                               <!-- <select name="agence" class="custom-select" multiple>
                                                    <option value="AgenceParcelles">Agence Parcelles</option>
                                                    <option value="AgenceFoire">Agence Foire</option>
													 </select>  -->
													 <?php
													  global $result;
													  echo '<select name="cboagence" class="styled-select" >';
													  echo '<option  value="'."".'">'."".'</option>';
												     	if(mysqli_num_rows($result) > 0 )
                                                         {
                                                   		   while ($row = mysqli_fetch_assoc($result))
															{
															  echo '<option  value="'.$row['telClient']."-".$row['nomClient'].'">'.$row['telClient']."-".$row['nomClient'].'</option>';
															}
															echo '</select>';
	                                                      }
													  ?>

                                            </li>
                                        </ul>
                                        </li>
										<li>
										<INPUT type= "radio" name="profil" value="backOffice" required> BACK OFFICE
										</li>
										<li>
										<INPUT type= "radio" name="profil" value="Admin_Distrib" required> DISTRIBUTEUR
										<ul>
										<li>
										 <!-- <select name="agence" class="custom-select" multiple>
                                                    <option value="AgenceParcelles">Agence Parcelles</option>
                                                    <option value="AgenceFoire">Agence Foire</option>
													 </select>  -->
													 <?php
													  global $resultDistrib;
													  echo '<select name="cbodistrib" class="styled-select" >';
													  echo '<option  value="'."".'">'."".'</option>';
												     	if(mysqli_num_rows($resultDistrib) > 0 )
                                                         {
                                                   		   while ($row = mysqli_fetch_assoc($resultDistrib))
															{
															  echo '<option  value="'.$row['telClient']."-".$row['nomClient'].'">'.$row['telClient']."-".$row['nomClient'].'</option>';
															}
															echo '</select>';
	                                                      }
													  ?>
										</li>
										</ul>

										</li>


                                    </ul>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="fonction">FONCTION</label>
                                    <select name="cbofonction" id="fonction" class="styled-select" >
									    <option value="" selected></option>
                                        <option value="Superviseur" selected>SUPERVISEUR</option>
                                        <option value="Caissier">CAISSIER</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="btn-modal-footer">
                        <div class="row">
                            <div class="col-md-4"></div>
                            <div class="col-md-4">
                                <input type="button" name="submit" value="Valider">
                            </div>
                            <div class="col-md-4"></div>
                        </div>
                        <!-- <input type="button" name="submit" value="Valider"> -->
                    </div>

                    </div>
                </div>
                </div>
				<?php

 $connect=connexion();


if (ISSET($_POST['submit'])) {

    $fonction = $_POST['cbofonction'];
    $agence = $_POST['cboagence'];
	$nom=$_POST['nom'];
	$prenom=$_POST['prenom'];
	$adresse=$_POST['adresse'];
	$tel=$_POST['tel'];
	$email=$_POST['email'];
	$cellulaire=$_POST['cellulaire'];
	$password=$_POST['password'];
	$password2=$_POST['password2'];
	$code=$_POST['code'];
	$code2=$_POST['code'];

	$_SESSION['nom']=$_POST['nom'];

	$_SESSION['prenom']=$_POST['prenom'];
	$_SESSION['adresse']=$_POST['adresse'];
	$_SESSION['tel']=$_POST['tel'];
	$_SESSION['email']=$_POST['email'];
	$_SESSION['cellulaire']=$_POST['cellulaire'];
	$_SESSION['password']=$_POST['password'];
	$_SESSION['password2']=$_POST['password2'];
	$_SESSION['code']=$_POST['code'];
	$_SESSION['code2']=$_POST['code2'];

	if (strcmp($password, $password2) !== 0) {
		//$location="./creerUser.php";
        //echo '<META HTTP-EQUIV="Refresh" Content="0; URL='.$location.'">';
		 echo "<meta http-equiv='refresh' content='0'>";
		echo '<script type="text/javascript">alert("Password incorrect")</script>' ;
		exit();
	}
	if (strcmp($code, $code2) !== 0) {
		//$location="./creerUser.php";
        //echo '<META HTTP-EQUIV="Refresh" Content="0; URL='.$location.'">';
		 echo "<meta http-equiv='refresh' content='0'>";
		echo '<script type="text/javascript">alert("Password incorrect")</script>' ;
		exit();
	}


if (isset($_POST['profil'])){
    	$profil = $_POST['profil'];
}
	switch ($profil) {
    case "Controleur":
	$fonction=$Siege;
        $retour=ajout_compte($profil,$fonction,$nom,$prenom,$adresse,$tel,$email,$cellulaire,$password,$code);
        break;
    case "Agence":
	$chAg=$_POST['cboagence'];
	if ($chAg=="") { echo '<script type="text/javascript">alert("Selectionner une agence")</script>' ; exit(); }
	 $chAg = explode("-", $_POST['cboagence']);
     $nomAgence=$chAg[1];
	$profil=$_POST['cbofonction'];

	 $retour=ajout_compte($profil,$nomAgence,$nom,$prenom,$adresse,$tel,$email,$cellulaire,$password,$code);
        break;
    case "backOffice":
	 //$chAg = explode("-", $_POST['cboagence']);
     //$nomAgence=$chAg[1];
	$profil=$_POST['cbofonction']."_BO";

	$fonction=$Siege;
	//echo $profil;
	 $retour=ajout_compte($profil,$fonction,$nom,$prenom,$adresse,$tel,$email,$cellulaire,$password,$code);
        break;
	case "Admin_Distrib":
	  $fonction=$_POST['cbodistrib'];
	   $chDistrib = explode("-", $_POST['cbodistrib']);
       $nomDistrib=$chDistrib[1];
	 // echo $profil.",".$numAgence.",".$nom.",".$prenom.",".$adresse.",".$tel.",".$email.",".$cellulaire.",".$password.",".$pin;
      $retour= ajout_compte($profil,$nomDistrib,$nom,$prenom,$adresse,$tel,$email,$cellulaire,$password,$code);
        break;
     }

  //  echo "Profil : ". $profil . " Nom : ".$nom." Fonction : ".$fonction." Agence : ".$agence;
   // echo Profil: '. $profil.' Nom : '. $nom .' Fonction: '. $fonction.' Agence : '. $agence;
    //header("Location: ./userList.php");

}


function ajout_compte($profil,$fonction,$nom,$prenom,$adresse,$tel,$email,$cellulaire,$password,$code){

	$creditCli = 0;
	$Commissions= 0;
	$max = 2147483647;
	$min = 1000000000;

	$value = rand($min, $max);
	$Num=substr($value,0,6);
    $id=(string)$Num;
   $connect=connexion();
   $activeGSM="oui";
    $activeWEB="oui";
   mysqli_set_charset($connect, "utf8");
   $accepter = "oui";
   $indicatifPays="00221";
   $Siege="Siege";
   $querySiege="select  telClient  from adherents where typeClient ='".$Siege."'";
   $resultSiege = mysqli_query($connect, $querySiege);
if(mysqli_num_rows($resultSiege) > 0 ) {
       while($resSiege = mysqli_fetch_array($resultSiege))
     {
       $numSiege=$resSiege['telClient'];
     }
}
	if ($numSiege==""){
	     return "";
		}
	if ($profil=="Distributeur"){ $numSiege=""; }
	$prenomNom=$prenom. " ". $nom ;
   $sql = "INSERT INTO adherents(nom,prenom,nomClient,indicatifPays,telClient,passwordClient,pinClient,adresse,mailClient,telfixe,cellulaire,creditClient,totalCommissions,Accepter,typeClient,agence,siege,paramWeb,paramGSM,dateInscription) VALUES
   ('$nom','$prenom','$prenomNom','$indicatifPays','$id','$password','$code','$adresse','$email','$tel','$cellulaire','$creditCli','$Commissions','$accepter','$profil','$fonction','$numSiege','$activeWEB','$activeGSM',now());";

  if (!mysqli_query($connect ,$sql))

   {
	   echo mysqli_error($connect);
	    //echo '<script type="text/javascript">alert("Echec")</script>' ;
     return "";
    die('Error: ' . mysqli_error($connect));
   }
   else
  {
 // echo '<script type="text/javascript">alert("Ajout effectué")</script>' ;

  $_SESSION['nom']="";
	$_SESSION['prenom']="";
	$_SESSION['adresse']="";
	$_SESSION['tel']="";
	$_SESSION['email']="";
	$_SESSION['cellulaire']="";
	$_SESSION['password']="";
	$_SESSION['password2']="";
	$_SESSION['code']="";
	$_SESSION['code2']="";
	$location="admin.php?section=user&page=userList";
    echo '<META HTTP-EQUIV="Refresh" Content="0; URL='.$location.'">';
    return "succes";
  }
   mysqli_close($connect);



}
?>
            </form>
</div>
