
<?php 
include('inc/connexion.php');
 $connect=connexion();
?>

<div class="row">
    <div class="col-md-12">
        <form action="pages/utilisateur/userList.php" method="post">
            <fieldset>
                <legend>Filtres</legend>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-inline">
                            <label for="fonction">Fonction : </label>
                           <select name="cbofonction" id="fonction" class="styled-select">
							<option value="TOUS">TOUS</option>
                     		    <option value="Caissier_BO">CAISSIER_BO</option>
                                <option value="Caissier">CAISSIER</option>
								<option value="Admin_Distrib">ADMIN_DISTRIB</option>
								<option value="Superviseur">SUPERVISEUR</option>
                                <option value="Superviseur_BO">SUPERVISEUR_BO</option>
								<option value="Controleur">CONTROLEUR</option>
								
                            </select>
                        </div>
                    </div>
                    
                </div>
                <div class="row mb-3">
                    <div class="col-md-12">
                        <button type="submit" name="afficher" >Afficher</button>
                    </div>
                </div>
            </fieldset>
        </form>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th scope="col">Login</th>
                    <th scope="col">Nom</th>
                    <th scope="col">PrÃ©nom</th>
                    <th scope="col">Affectation</th>
                    <th scope="col">Fonction</th>
                    <th scope="col">DÃ©marrÃ©e Ã </th>
                    <th scope="col">MÃ©dia</th>
                    <th scope="col">Mode</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>log1234</td>
                    <td>BA</td>
                    <td>Alassane</td>
                    <td>Agence Foire</td>
                    <td>Administrateur</td>
                    <td>06/10/2018 <br> 12:21</td>
                    <td>192.168.14.56</td>
                    <td>WEB</td>
                    <td class="text-center"><a href="#" id="btn-retirer" data-toggle="modal" data-target="#confirmation"><i class="fa fa-2x fa-power-off" style="color:green"></i></a></td>
                </tr>
               
				<?php     
				  
				  if (ISSET($_POST['afficher'])) {   
				    echo ("submit");
				    $connect=connexion();
                    mysqli_set_charset($connect, "utf8"); 
					$typ=$_POST['cbofonction'];
					$_SESSION['typ']=$typ;
					$active="oui";
					if ($typ=="TOUS"){
						  $query="select  * from adherents  where sessionactive='".$active."' order by nomClient";
					}else
					{
						  $query="select  * from adherents where sessionactive='".$active."' and typeClient='".$typ."' order by nomClient ";
						  // echo $query;
					}
                    
                    $result = mysqli_query($connect, $query);
					if(mysqli_num_rows($result) > 0 ) 
					{
					   while($res = mysqli_fetch_array($result))
					   {
							echo" <tr>";
							echo"<td align=center width='20'>".$res['telClient']."</td>";
							echo"<td align=center width='20'>".$res['nom']."</td>";
							echo"<td align=center width='20'>".$res['prenom']."</td>";
							
							
							echo"<td align=center width='20'>".$res['typeClient']."</td>";
							echo"<td align=center width='20'>".$res['agence']."</td>";
							//$location="admin.php?section=user&page=userList";
                           // echo '<META HTTP-EQUIV="Refresh" Content="0; URL='.$location.'">';
							$action='<td class="text-center" width="5"><a href="admin.php?section=user&page=userEdit&id='.$res['telClient'].'"><i class="fa fa-edit"></i></a></td>';
							echo $action;
							echo" </tr>";
							 
					   }
					}
					 mysqli_close($connect);
					
				    }
				   
				   else
					 {					
				 
				
					mysqli_set_charset($connect, "utf8"); 
					 $Superviseur="Superviseur";
					 $Distributeur="Admin_Distrib";
					 $Superviseur_BO="Superviseur_BO";
					 $Caisse_BO="Caissier_BO";
					 $Controleur="Controleur";
					 $Caisse="Caissier";
					 $active="oui";
					$query="select  * from adherents where sessionactive='".$active."' and (typeClient='".$Superviseur."' or typeClient='".$Distributeur."' or typeClient='".$Superviseur_BO."' or typeClient='".$Caisse_BO."' or typeClient='".$Controleur."' or typeClient='".$Caisse."') order nomClient ";
                     //$query="select  * from adherents where order nomClient ";
					 					
					$result = mysqli_query($connect, $query);
					 	   				  
					if(mysqli_num_rows($result) > 0 ) 
					{
					   while($res = mysqli_fetch_array($result))
					   {
							echo" <tr>";
							echo"<td align=center width='20'>".$res['telClient']."</td>";
							echo"<td align=center width='20'>".$res['nom']."</td>";
							echo"<td align=center width='20'>".$res['prenom']."</td>";
							
							
							echo"<td align=center width='20'>".$res['typeClient']."</td>";
							echo"<td align=center width='20'>".$res['agence']."</td>";
							
							echo" </tr>";
							 
					   }
					}
					 mysqli_close($connect);		
				   }
				    
			    ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="9">
                        <nav aria-label="Page navigation example">
                            <ul class="pagination">
                                <li class="page-item">
                                    <a class="page-link" href="#" tabindex="-1"><i class="fa fa-angle-double-left"></i></a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="#">1</a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="#">2</a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="#">3</a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="#"><i class="fa fa-angle-double-right"></i></a>
                                </li>
                            </ul>
                        </nav>
                    </td>
                </tr>
            </tfoot>
        </table>
    </div>
</div>

<div class="modal" tabindex="-1" role="dialog" id="confirmation">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">DÃ©connecter l'utilisateur</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p>Voulez-vous confirmer ?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">NON</button>
        <button type="button" class="btn btn-defaul">OUI</button>
      </div>
    </div>
  </div>
</div>