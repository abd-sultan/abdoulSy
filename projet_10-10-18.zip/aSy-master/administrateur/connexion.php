﻿<?php
    //On démarre la session avant d'écrire du code HTML
    session_start();
    $connect="";
	$test="1";
   // On créait la session `essai` si elle n'existe pas :
   if(!isset($_SESSION['essai'])) $_SESSION['essai'] = 0;

?>
<?php
// On vérifie que le nombre d'essai n'a pas été dépassé :
if($_SESSION['essai'] > 3)
{


	$retour=verouillage();



}
function verouillage(){
  global $connect;
 $host_name = 'localhost';
 $database = 'compte_samba';
 $user_name = 'root';
 $password = '';

   $connect = mysqli_connect($host_name, $user_name, $password, $database);
 mysqli_set_charset($connect, "utf8");
    $tel=$_SESSION['numero'];
   $non="oui";
    $query="update adherents SET Accepter='".$non."'  where telClient ='".$tel."'";



	 if(mysqli_query($connect, $query)){
                  if (mysqli_affected_rows($connect) > 0){
				  $msg="Vous avez depasse le nombre de tentative, le compte est verouille."." <br />"."Veillez contacter votre administrateur";

	               echo utf8_encode($msg);
				   exit();
				  }
	}
}
?>
<html>
    <head>
       <meta charset="utf-8">
        <!-- importer le fichier de style -->
        <!-- <link rel="stylesheet" href=".\css\style.css" media="screen" type="text/css" /> -->
        <link rel="stylesheet" href="assets/css/forms.css" type="text/css" />
        <link rel="stylesheet" href="assets/css/menu.css" type="text/css" />
    </head>
    <body>
        <div id="container">
            <!-- zone de connexion -->

             <!-- zone de connexion -->

 <br>
 <br>
 <br>
 <br>
 <table    align='center' width='300'>

 <form method="POST" >
 <table   border='1' align='center' width='300'>


   <tr >
           <td>
	<div id="cadrebis" align="left">

                <label><b>Identification</b></label>
                <input type="number" placeholder="Entrer le numéro " name="Tel" required>

                <label><b>Code Secret</b></label>
                <input type="password" placeholder="Entrer le Code Secret" name="MotdePasse" required>


                <input type="submit" name='submit' value='LOGIN' >

				<br>

				</br>

				<a href="recupcodesecret.php"><font color="67BE4B">Code Secret oublié</font></a>

				<br>

				</br>

								  </div>
</td>
                <?php
                if(isset($_GET['erreur'])){
                    $err = $_GET['erreur'];
                    if($err==1 || $err==2)
                        echo "<p style='color:red'>Utilisateur ou mot de passe incorrect</p>";
                }
                ?>


<?php

if(!isset($_POST['Tel']) || !isset($_POST['MotdePasse']))
{

  die();
}


 if(isset($_POST['submit'])){

	$host_name = 'localhost';
 $database = 'compte_samba';
 $user_name = 'root';
 $password = '';


 //$tel = $_POST['Tel'];
 //$motdePasse = $_POST['MotdePasse'];



 $connect = mysqli_connect($host_name, $user_name, $password, $database);
$tel=mysqli_real_escape_string($connect,htmlspecialchars($_POST['Tel']));
$motdePasse=mysqli_real_escape_string($connect,htmlspecialchars($_POST['MotdePasse']));
 $_SESSION['numero']=$tel;


 if(mysqli_connect_errno())
 {
 echo 'Connexion au serveur MySQL a echoue:';
 }
 else
 {


   global $test;

   mysqli_set_charset($connect, "utf8");

   $Accepter="oui";
    $query="select  *  from adherents where telClient ='".$tel."' and passwordClient ='".$motdePasse."' and Accepter ='".$Accepter."'";

    $result = mysqli_query($connect, $query);

    if(mysqli_num_rows($result) > 0 ) {
       while($res = mysqli_fetch_array($result))
       {
       // echo "succes" ;
		$typ=$res['typeClient'];
		$_SESSION['type']=$typ;
		$_SESSION['nomAdherent']=$res['nomClient'];
		$rattachement=$res['agence'];
        $rattachementSiege=$res['siege'];
		$rattachementAgence=$res['agence'];
        $DateDerniereConnexion=$res['DateConnexion'];
       }
       // echo $typ;
		// if ($typ=="Siege") {
		//		header("location:http://www2.senevens.fr/TestAcceesWeb/interfacesiegeperiode.php?tel=".$tel);
		//}
       //  if ($typ=="Agence") {
		//		header("location:http://www2.senevens.fr/TestAcceesWeb/interfaceagenceperiode.php?tel=".$tel);
		//}

       //header("location:http://www2.senevens.fr/TestAcceesWeb/interfacelisteengagement.php");
       /* if ($typ=="Siege")
 	     {
	      header("location:http://www2.senevens.fr/TestAcceesWeb/option.php?type=".$typ."&tel=".$tel);
         } */

		 if ($typ=="backOffice")
 	     {

	     // header("location:http://www2.senevens.fr/TestAcceesWeb/optionbackoffice.php");
		    header("location: Backoffice/menubackoffice.php");
		  $_SESSION['essai']=0;
          $_SESSION['DateDerniereConnexion']=$DateDerniereConnexion;
		  $_SESSION['Du']="";
		  $_SESSION['Au']="";
		  $_SESSION['last_access']=time();
		  $sessionactive="oui";


         }

		 	 if ($typ=="Distributeur")
 	     {


		    header("location: Distrib/Distributeur.php");
		  $_SESSION['essai']=0;
$_SESSION['DateDerniereConnexion']=$DateDerniereConnexion;
 $_SESSION['last_access']=time();
		  exit();

         }
		  	 if ($typ=="SousDistributeur")
 	     {

	      $_SESSION['Siege']=$rattachement;
		  $_SESSION['Distrib']=$rattachement;
$_SESSION['DateDerniereConnexion']=$DateDerniereConnexion;
 $_SESSION['last_access']=time();
		    header("location: SousDistrib/SousDistributeur.php");
		  $_SESSION['essai']=0;
		  exit();

         }
 	 if ($typ=="Caisse")
 	     {

	      $_SESSION['Siege']=$rattachementSiege;
		  $_SESSION['Agence']=$rattachementAgence;
		   $_SESSION['DateDerniereConnexion']=$DateDerniereConnexion;
		    $_SESSION['last_access']=time();
		    header("location: Caisse/Caisse.php");
		  $_SESSION['essai']=0;
		  exit();

         }
if ($typ=="Superviseur")
 	     {


		   $_SESSION['DateDerniereConnexion']=$DateDerniereConnexion;
		    $_SESSION['last_access']=time();
           $_SESSION['Rattachement']=$rattachementAgence;
		    header("location: Superviseur/Superv.php");
		  $_SESSION['essai']=0;
		  exit();

         }
if ($typ=="SuperviseurCA")
 	     {


		   $_SESSION['DateDerniereConnexion']=$DateDerniereConnexion;
		    $_SESSION['last_access']=time();
           $_SESSION['Rattachement']=$rattachementAgence;
		    header("location: SuperviseurCA/Superv.php");
		  $_SESSION['essai']=0;
		  exit();

         }
      if ($typ=="Administrateur"){



		  $_SESSION['nomAdherent']="Administrateur";
        $_SESSION['DateDerniereConnexion']=$DateDerniereConnexion;
         $_SESSION['last_access']=time();

	 $_SESSION['essai']=0;
	  $heureactuelconnection=time();
	  $sessionactive="oui";
		  //$UpdateHeureConnexion = "UPDATE adherents SET sessionactive='".$sessionactive."',heureactuelconnection='".$heureactuelconnection."' WHERE telClient='".$tel."'";
          //echo $UpdateHeureConnexion;
          // if(mysqli_query($connect, $UpdateHeureConnexion)){
		  //   if (mysqli_affected_rows($connect) > 0){
			 //header("location: Admin/Admin.php");
             header("location: ../administrateur/admin.php");
		// 	   exit();
        //    } else {
        //        echo "connecté E2";
        //    }
		// 	}
        // } else {
        //     // echo "non connecté";
        // }
	}
   else
   {
        $_SESSION['essai']++;

		// Puis on redirige le visiteur vers la page d'authentification :
		header('Location: ./connexion.php');
		exit();

    }

    mysqli_close($connect);
}
}}


?>



	</td>
</tr>

  </table>
   </form>
   </table>

    </body>
</html>
